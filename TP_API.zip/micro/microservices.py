import pymysql
from flask import request, jsonify  # joson format
from micro1 import mysql
from flask import Flask
from flask_cors import CORS, cross_origin
import time

import pymysql
from app import app
from micro1 import mysql   #database file
from flask import request, jsonify  # joson format
import requests


#########################################################

'''LIST OF GTINS'''

@app.route('/microservices/v1.0.0/product/gtin/list')
def gtin_list():
    lst = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin FROM gtin_summary")
    gtin = cursor.fetchall()
    for i in gtin:
        lst.append(i['gtin'])
    result = {'gtin-list': lst}
    return jsonify(result)
    cursor.close()
    conn.close()

if __name__ == "__main__":
    #app.run(host=app.config['api.tracepharm.io'],port=5000,debug=True)
    app.run(host='0.0.0.0', debug=True)