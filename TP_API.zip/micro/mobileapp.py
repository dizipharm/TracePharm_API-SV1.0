import re
import time
import datetime

import MySQLdb
import pymysql

from micro1 import mysql   #database file

import requests

from flask import Flask, jsonify, request, session, render_template
from werkzeug.security import generate_password_hash, check_password_hash
from flask_cors import CORS
from datetime import timedelta

app = Flask(__name__)

app.config['SECRET_KEY'] = 'cairocoders-ednalan'

app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=10)
CORS(app)

##############list of all gtins##########
@app.route('/api/micro/v1/product/gtin_list')
def gtin_list():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin FROM gtin_summary")
    gtin_list = cursor.fetchall()
    result = {'gtins': gtin_list}
    return jsonify(result)
    cursor.close()
    conn.close()

########## count of all gtin list #############

@app.route('/api/micro/v1/product/gtin-counts')
def gtin_count():
    lst = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin FROM mt_product_gtin")
    gtin = cursor.fetchall()
    for i in gtin:
        lst.append(i['gtin'])

    result = len(lst)
    return jsonify({'gtin_count':result})
    cursor.close()
    conn.close()

####################active and inactive###########

@app.route('/api/micro/v1/product/gtin/status')
def gtin_is_active():
    gtin_status = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT id, gtin, is_active FROM gtin_summary")
    gtin_data = cursor.fetchall()

    result = {'status': gtin_data}
    return jsonify(result)
    cursor.close()
    conn.close()


#########################
@app.route('/api/micro/v1/product/gtin-info/')
def gtin_info():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM mt_product_gtin")
    gtin = cursor.fetchall()

    result = {'gtin_info': gtin}
    return jsonify(result)
    cursor.close()
    conn.close()

######################### Status of particular gtin number #######


@app.route('/api/micro/v1/product/gtin-status/<string:gtin>')
def specific_gtin_is_active(gtin):
    active =  []
    inactive =  []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin, is_active FROM mt_product_gtin WHERE gtin=%s",gtin)
    gtin_data = cursor.fetchall()
    for i in gtin_data:
        if i['is_active'] == 1:
            gtin_num  = i['gtin']
            a = 'gtin staus is active'
        else:
            a = 'gtin staus is inactive'
            gtin_num  = i['gtin']

    result =({'gtins_status':a , 'gtin_number': gtin_num})
    return jsonify(result)
    cursor.close()
    conn.close()

#################################### Lot number ###############################

############list of the lot wrt gtin ###########

@app.route('/api/micro/v1/product/lot-list/<string:gtin>')
def list_of_lot(gtin):
    lot_list = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()

    for i in lot_data:
        lot_num =  i['batch_no']
        lot_list.append(lot_num)


    result =({'lot_list':lot_list })
    return jsonify(result)
    cursor.close()
    conn.close()

################### lot count ##################

@app.route('/api/micro/v1/product/lot-count/<string:gtin>')
def lot_count(gtin):
    lot_list = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()

    for i in lot_data:
        lot_num =  i['batch_no']
        lot_list.append(lot_num)


    result =({'lot_list':len(lot_list) })
    return jsonify(result)
    cursor.close()
    conn.close()


################ lot information #####################

@app.route('/api/micro/v1/product/lot-info/<string:gtin>')
def lot_info(gtin):

    lotinfo = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()

    for i in lot_data:

        lotinfo['lot_information'] =  i

    result =(lotinfo)
    return jsonify(result)
    cursor.close()
    conn.close()

####################### item #####################
############### list of serial number  ##########################

@app.route('/api/micro/v1/product/item-serial-list/<string:gtin>') #api/micro/v1/product/item-serial-list?lotnumber= 12345
def serial_num_list(gtin):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_item_pack_type_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()
    serial_num_list = []
    for i in lot_data:
        if request.args:
            lot_num = request.args.get('lotnumber')
            if lot_num == i['batch_no']:
                serial = i['package_sn']
                serial_num_list.append(serial)

    result =({'list_of_serial_number':serial_num_list})

    return jsonify(result)
    cursor.close()
    conn.close()

################### count of serial number  ############

@app.route('/api/micro/v1/product/item-serial-list-count/<string:gtin>')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def serial_num_count(gtin):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_item_pack_type_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()
    serial_num_list = []
    for i in lot_data:
        if request.args:
            lot_num = request.args.get('lotnumber')
            if lot_num == i['batch_no']:
                serial = i['package_sn']
                serial_num_list.append(serial)

    result =({'list_of_serial_number':len(serial_num_list)})

    return jsonify(result)
    cursor.close()
    conn.close()

################################Location Summary#####################################

@app.route('/api/micro/v1/product/item_location-info/<string:package_sn>')
def item_location_info(package_sn):

    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM location_summary WHERE package_sn=%s", package_sn)
    package_sn = cursor.fetchall()

    result ={'gtin_info': package_sn }
    return jsonify(result)
    cursor.close()
    conn.close()


##########################Owner Summary####################################

@app.route('/api/micro/v1/product/item_owner-info/<string:package_sn>')
def item_owner_info(package_sn):

    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT current_owner_gln,current_owner_name,package_sn,batch_no,product_gtin,transaction_timestamp FROM vw_item_transactions WHERE package_sn=%s", package_sn)
    package_sn = cursor.fetchall()

    result ={'item_owner_info': package_sn }
    return jsonify(result)
    cursor.close()
    conn.close()
#############################################################################
###########################################################################################################
@app.route('/api/micro/v1/product/transaction')
def transaction_information():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_item_transactions")
    transaction = cursor.fetchall()

    result = {'transaction': transaction}
    return jsonify(result)
    cursor.close()
    conn.close()


#####################################################

@app.route('/api/micro/v1/product/currrent-location')
def location_information():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_location_summary")
    location = cursor.fetchall()
    result = {'transaction': location}
    return jsonify(result)
    cursor.close()
    conn.close()


#################################################

@app.route('/api/micro/v1/product/trans_type')
def trans_type():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_package_transaction")
    transac = cursor.fetchall()
    result = {'transaction': transac}
    return jsonify(result)
    cursor.close()
    conn.close()


############################################

@app.route('/api/micro/v1/package/info')
def package_info():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_package")
    package = cursor.fetchall()
    result = {'transaction': package}
    return jsonify(result)
    cursor.close()
    conn.close()


#####################################
@app.route('/api/micro/v1/package/transaction')
def package_transaction():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_package_transaction_summary")
    package  = cursor.fetchall()
    result = {'package_transaction': package}
    return jsonify(result)
    cursor.close()
    conn.close()

##################################################
@app.route('/api/v1/product/track/<string:sscc>')
def transaction_information_1(sscc):
    package_info = requests.get('http://3.86.246.56:5000/api/micro/v1/package/info').json()
    current_location = requests.get('http://3.86.246.56:5000/api/micro/v1/product/currrent-location').json()
    ssccinfo = {}
    for i in package_info['transaction']:
        if sscc == i['sscc_no']:
            ssccinfo['lot_number'] = i['batch_no']
            ssccinfo['package_colour'] = i['colour']
            ssccinfo['depth'] = i['depth']
            ssccinfo['gtin'] = i['gtin']
            ssccinfo['height'] = i['height']
            ssccinfo['inner_serail_count'] = i['inner_serail_count']
            ssccinfo['inner_serail_list'] = i['inner_serail_list']
            ssccinfo['package_pallet_sn'] = i['package_pallet_sn']
            ssccinfo['package_type'] = i['package_type']
            ssccinfo['shape'] = i['shape']
            ssccinfo['sscc_number'] = i['sscc_no']
            ssccinfo['dimensions'] = i['total_dimensions']
            ssccinfo['width'] = i['width']
            ssccinfo['current_location'] = 'http://3.86.246.56:5000/api/micro/v1/product/currrent-location'
            ssccinfo['current_owner_info'] = 'http://3.86.246.56:5000/api/micro/v1/package/transaction'

    result = ({'package_inforamtion': ssccinfo})

    return jsonify({'message': 'sscc not found in records'} if ssccinfo == {} else result)

##########################################################

@app.route('/api/v2/product/track')
def track_sys():
    package_info = requests.get('http://3.86.246.56:5000/api/micro/v1/package/info').json()
    package = []
    for i in package_info['transaction']:
        package.append(
            {'package_info': i, 'current_location': 'http://3.86.246.56:5000/api/micro/v1/product/currrent-location',
             'current_owner': "http://3.86.246.56:5000/api/micro/v1/package/transaction"})

    return jsonify({'track_info': package})
###########################################
@app.route('/api/v3/product/pakage_track/<string:sscc>')
def transaction_information_2(sscc):
    t1 = time.time()
    track_info = requests.get('http://3.86.246.56:5000/api/v2/product/track').json()
    pack = {}
    for i in track_info['track_info']:
        if i['package_info']['sscc_no'] == sscc:
            pack['package_information'] = i['package_info']
            current_owner = requests.get(i['current_owner']).json()
            owner = current_owner['package_transaction']
            for j in owner:
                if sscc == j['sscc_no']:
                 pack['current_owner'] = j
            current_location = requests.get(i['current_location']).json()
            location = current_location['transaction']
            for k in location:
                if sscc == k['sscc_no']:
                    pack['location'] = k
    t2 = time.time()
    time_1 = ("Elasped Time(Sec): ",round(t2-t1,5),"sec")
    result = {'pack_info': pack, 'Respose time': time_1}
    return jsonify ({'message':'Sorry! No records available'}if pack == {} else result)

#################################################
@app.route('/api/v3/product/package_track/<string:sscc>')
def transaction_information_3(sscc):
    t1 = time.time()
    track_info = requests.get('http://3.86.246.56:5000/api/v2/product/track').json()
    main_data = []
    pack = {}
    owner_data = {}
    entry_point = {}
    exit_point = {}
    owner_data_location = {}
    location = {}
    entry_point_location = {}
    exit_point_location = {}
    transaction_event = {}
    transaction_status = {}
    for i in track_info['track_info']:
        if i['package_info']['sscc_no'] == sscc:
            pack['lot_number'] = i['package_info']['batch_no']
            pack['colour'] = i['package_info']['colour']
            pack['height'] = i['package_info']['height']
            pack['inner_serialNumber_count'] = i['package_info']['package_inside_units']
            pack['inner_serailNumber_list'] = i['package_info']['inner_serail_list']

            pack['package_type'] = i['package_info']['package_type']
            pack['package_serialNumber'] = i['package_info']['package_pallet_sn']
            pack['shape'] = i['package_info']['shape']
            pack['sscc_no'] = i['package_info']['sscc_no']
            if i['package_info']['is_active'] == 1:
                pack['status'] = 'transaction status is active'
            else:
                pack['status'] = 'transaction status is in-active'

            current_owner = requests.get(i['current_owner']).json()
            owner = current_owner['package_transaction']
            for j in owner:
                if sscc == j['sscc_no']:
                    owner_data['current_owner'] = j['current_owner']
                    owner_data['current_owner_address'] = j['current_owner']
                    owner_data['current_owner_address'] = j['street_address1']

                    entry_point['company_name'] = j['consigner']
                    entry_point['address'] = j['consigner_address']

                    exit_point['comapny_name'] = j['consignee']
                    exit_point['company_address'] = j['consignee_address']

                    transaction_event['handoff_event'] = j['tranc_date_time']
                    transaction_status['transaction_status'] = j['event_type']

            current_location = requests.get(i['current_location']).json()
            location_curr = current_location['transaction']
            for k in location_curr:
                if sscc == k['sscc_no']:
                    owner_data['gln'] = k['company_gln']
                    location['current_lat'] = k['current_lat']
                    location['current_long'] = k['current_long']
                    location['current_location'] = k['current_location']
                    location['temperature'] = k['temperature']
                    location['humidity'] = k['humidity']

                    entry_point_location['latitude'] = k['entry_lat']
                    entry_point_location['longitude'] = k['entry_long']
                    entry_point['gln'] = k['entry_point_gln']

                    exit_point_location['latitude'] = k['exit_latitude']
                    exit_point_location['longitude'] = k['exit_long']
                    exit_point['gln'] = k['exit_point_gln']

    t2 = time.time()
    time_1 = ("Elasped Time(Sec): ", round(t2 - t1, 5), "sec")
    result = {'pack_info': pack, 'Respose time': time_1, 'owner_info': owner_data, 'exit_point': exit_point,
              'entry_point': entry_point,
              'current_location': location, 'entry_point_location': entry_point_location,
              'exit_point_location': exit_point_location,
              'transaction_status': transaction_status, 'transaction_event': transaction_event}
    return jsonify({'message': 'Sorry! No records available'} if pack == {} else result)


############################
@app.route('/api/micro/v1/package/item-information')
def item_information():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_item_pack_type_summary")
    package  = cursor.fetchall()
    result = {'item_information': package}
    return jsonify(result)
    cursor.close()
    conn.close()

##################### for item #####################
@app.route('/api/v2/product/track/item_info')

def item_track_info():

    package_info = requests.get('http://3.86.246.56:5000/api/micro/v1/package/item-information').json()
    item = []
    for i in package_info['item_information']:
        item.append({'item_info': i, 'current_location':'http://3.86.246.56:5000/api/micro/v1/product/currrent-location',
        'current_owner': "http://3.86.246.56:5000/api/micro/v1/product/item/transaction", 'package_info':"http://3.86.246.56:5000/api/micro/v1/package/info"})


    return jsonify({'track_info': item })
############# micro for item track ###################

@app.route('/api/micro/v1/product/item/transaction')
def item_transaction():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_item_transactions ")
    item  = cursor.fetchall()
    result = {'package_transaction': item}
    return jsonify(result)
    cursor.close()
    conn.close()
###################
@app.route('/api/v2/product/track/item_sys')
def item_track_sys():
    package_info = requests.get('http://3.86.246.56:5000/api/micro/v1/package/item-information').json()
    item = []
    for i in package_info['item_information']:
        item.append(
            {'item_info': i, 'current_location': 'http://3.86.246.56:5000/api/micro/v1/product/currrent-location',
             'current_owner': "http://3.86.246.56:5000/api/micro/v1/product/item/transaction",
             'package_info': "http://3.86.246.56:5000/api/micro/v1/package/info"})

    return jsonify({'track_info': item})


###########################    track with serial and lot  ###########################

@app.route('/api/v3/product/track/item/<string:gtin>')
def item_transaction_information(gtin):
    t1 = time.time()
    track_info = requests.get('http://3.86.246.56:5000/api/v2/product/track/item_sys').json()
    main_data = []
    item = {}
    owner_data = {}
    entry_point = {}
    exit_point = {}
    controll_condition = {}
    owner_data_location = {}
    location = {}
    entry_point_location = {}
    exit_point_location = {}
    transaction_event = {}
    transaction_status = {}
    for i in track_info['track_info']:
        if i['item_info']['gtin'] == gtin:
            if request.args:
                serial_num = request.args.get('serialNumber')
                lot_num = request.args.get('lotNumber')
                if serial_num == i['item_info']['package_sn'] and lot_num == i['item_info']['batch_no']:

                    item['lot_number'] = i['item_info']['batch_no']
                    item['product_name'] = i['item_info']['product_name']
                    item['brand'] = i['item_info']['brand_name']
                    item['expiry_date'] = i['item_info']['expiry_date']
                    item['manufacturing_date'] = i['item_info']['mfg_date']
                    item['package_type'] = i['item_info']['item_pack_type']
                    item['quantity'] = i['item_info']['item_inner_count']
                    item['serial_number'] = i['item_info']['package_sn']
                    if i['item_info']['is_active'] == 1:
                        item['status'] = 'transaction status is active'
                    else:
                        item['status'] = 'transaction status is in-active'

                    current_owner = requests.get(i['current_owner']).json()
                    owner = current_owner['package_transaction']
                    for j in owner:
                        if serial_num == j['package_sn'] and lot_num == j['batch_no']:
                            owner_data['current_owner'] = j['current_owner_name']
                            entry_point['owner'] = j['entry_point_owner']
                            entry_point['address'] = j['entry_point_owner_location']

                            exit_point['comapny_name'] = j['exit_point_owner']
                            exit_point['company_address'] = j['exit_point_owner_location']

                            transaction_event['handoff_event'] = j['transaction_timestamp']
                            transaction_status['transaction_status'] = j['item_status']

                    current_location = requests.get(i['current_location']).json()
                    location_curr = current_location['transaction']
                    for k in location_curr:
                        if serial_num == k['package_sn']:
                            owner_data['gln'] = k['company_gln']
                            location['current_lat'] = k['current_lat']
                            location['current_long'] = k['current_long']
                            owner_data['current_owner_address'] = k['current_owner_address_id']

                            entry_point_location['latitude'] = k['entry_lat']
                            entry_point_location['longitude'] = k['entry_long']
                            entry_point['gln'] = k['entry_point_gln']

                            exit_point_location['latitude'] = k['exit_latitude']
                            exit_point_location['longitude'] = k['exit_long']
                            exit_point['gln'] = k['exit_point_gln']

                            controll_condition['temperature'] = k['temperature']
                            controll_condition['humidity'] = k['humidity']

    t2 = time.time()
    time_1 = ("Elasped Time(Sec): ", round(t2 - t1, 5), "sec")
    result = {'pack_info': item, 'Respose time': time_1, 'owner_info': owner_data, 'exit_point': exit_point,
              'entry_point': entry_point,
              'current_location': location, 'entry_point_location': entry_point_location,
              'exit_point_location': exit_point_location,
              'transaction_status': transaction_status, 'transaction_event': transaction_event,
              'controll_conditions': controll_condition}
    return jsonify({'message': 'Sorry! No records available'} if item == {} else result)

############################################
# LOT INFO
#####################################

@app.route('/api/micro/v1/product/lot/list')
def lot_list():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT id, batch_no, gtin FROM gtin_lot_summary")
    lot_list = cursor.fetchall()
    result = {'lot_list': lot_list}
    return jsonify(result)
    cursor.close()
    conn.close()

###############lot active in active ################

@app.route('/api/micro/v1/product/lot/status')
def lot_is_active():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT id, batch_no, gtin, is_active FROM gtin_lot_summary")
    lot_data = cursor.fetchall()
    result = {'lot_status': lot_data}
    return jsonify(result)
    cursor.close()
    conn.close()


############ lot info ##############

@app.route('/api/micro/v1/product/lot/info')
def lot_is_info():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        "SELECT id, batch_no, gtin, is_active, mfg_date, expiry_date, lot_qty, company_gln,company_name,mfg_address FROM gtin_lot_summary")
    lot_data = cursor.fetchall()
    result = {'lot_info': lot_data}
    return jsonify(result)
    cursor.close()
    conn.close()

######################package##################

############# sscc_list ################

@app.route('/api/micro/v1/package/sscc/list')
def package_sscc_list():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT sscc_no FROM vw_package")
    lot_data = cursor.fetchall()
    result = {'lot_info': lot_data}
    return jsonify(result)
    cursor.close()
    conn.close()


################## sscc_info ###################

@app.route('/api/micro/v1/package/sscc/info')
def package_sscc_info():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_package")
    lot_data = cursor.fetchall()
    result = {'lot_info': lot_data}
    return jsonify(result)
    cursor.close()
    conn.close()

##########################################################################
                    # IDENTIFICATION
##########################################################################
############################## list of gtin ##################################

@app.route('/api/v1/product/identification/gtin/list')
def gtin_lists():
    gtin_list = requests.get('http://3.86.246.56:5000/api/micro/v1/product/gtin_list').json()
    gtins = []
    for i in gtin_list['gtins']:
        gtins.append(i['gtin'])
    result= ({'gtin_list': gtins})
    return jsonify( {'message': 'no records found'} if gtins == [] else result)


########################### list of count ##################

@app.route('/api/v1/product/identification/gtins/count')
def gtin_counts():
    gtin_list = requests.get('http://3.86.246.56:5000/api/micro/v1/product/gtin_list').json()
    gtins = []
    for i in gtin_list['gtins']:
        gtins.append(i['gtin'])
    result= ({'gtin_list': len(gtins)})
    return jsonify( {'message': 'no records found'} if gtins == [] else result)

#######################gtin info###########################

@app.route('/api/v1/product/identification/gtins/info/<string:gtin>')
def gtin_sys_info(gtin):
    gtin_data = requests.get('http://3.86.246.56:5000/api/micro/v1/product/gtin-info').json()
    gtin_info = {}

    for i in gtin_data['gtin_info']:
        if gtin == i['gtin']:
            gtin_info['gtin'] = i['gtin']
            gtin_info['labler_name'] = i['labler_name']
            gtin_info['last_updated_datetime'] = i['last_updated_datetime']
            gtin_info['brand'] = i['brand_name']
            gtin_info['product_form'] = i['product_form']
            gtin_info['product_name'] = i['product_name']
            gtin_info['ndc_code'] = i['product_ndc']
            gtin_info['strength'] = i['strength']
            gtin_info['product_discription'] = i['product_discription']
            gtin_info['patient_instruction'] = i['patient_instruction']
            if i['is_active'] == 1:
                status = 'Product status is Active '
                gtin_info['product_status'] = status
            else:
                status = 'Product status is In-active '
                gtin_info['product_status'] = status

        gtin_image_data = requests.get('http://3.239.56.34:8003/product_gtin/').json()
        for j in gtin_image_data:
            if gtin == j['gtin']:
                image = j['product_image_url']
                gtin_info['product_image'] = image

    result = ({'gtin_information': gtin_info})
    return jsonify({'message': 'no records found'} if gtin_info == [] else result)
###################################################################################################################
###########################################################################################################
                                                # lot information
###########################################################################################################
##############list of lot ########################
@app.route('/api/v1/product/identification/lot/list/<string:gtin>')
def lot_list_info(gtin):
    lot_list_data = requests.get('http://3.86.246.56:5000/api/micro/v1/product/lot/list').json()
    lot = []
    for i in lot_list_data['lot_list']:
        if i['gtin'] == gtin:
            lot.append(i['batch_no'])

    result= ({'list_of_lot': lot})
    return jsonify(result)
#######################
################## count of lot WRT gtin ####################################
@app.route('/api/v1/product/identification/lot/count/<string:gtin>')
def lot_count_gtin(gtin):
    lot_list_data = requests.get('http://3.86.246.56:5000/api/micro/v1/product/lot/list').json()
    lot = []
    for i in lot_list_data['lot_list']:
        if i['gtin'] == gtin:
            lot.append(i['batch_no'])

    result= ({'list_of_lot': len(lot)})
    return jsonify(result)


########################### gtin+lot info+ serial info ####################
@app.route('/api/v1/product/identification/lot/serial_list/<string:gtin>')
def lot_serial_list(gtin):
    lot_serial_list_data = requests.get('http://3.86.246.56:5000/api/micro/v1/package/item-information').json()

    serial_list = []
    for i in lot_serial_list_data['item_information']:
        if i['gtin'] == gtin:
            if request.args:
                lot_num = request.args.get('lotNumber')
                if i['batch_no'] == lot_num:
                    serial_list.append(i['package_sn'])

    result = [{'serial_list': serial_list}]

    return jsonify({'message': 'no records found'} if serial_list == [] else result)

########################### serial_number info  ###################################

@app.route('/api/v1/product/identification/item/serial_info/<string:gtin>')
def serial_info(gtin):
    lot_serial_list_data = requests.get('http://3.86.246.56:5000/api/micro/v1/package/item-information').json()

    serial_info = {}
    for i in lot_serial_list_data['item_information']:
        if i['gtin'] == gtin:
            if request.args:
                lot_num = request.args.get('lotNumber')
                serial_num = request.args.get('serialNumber')
                if i['batch_no'] == lot_num and serial_num == i['package_sn']:
                    serial_info['product_name'] = i['product_name']
                    serial_info['brand_name'] = i['brand_name']
                    serial_info['company_name'] = i['company_name']
                    serial_info['company_gln'] = i['company_gln']
                    serial_info['mfg_address'] = i['mfg_address']
                    serial_info['package_type'] = i['item_pack_type']
                    serial_info['image'] = i['package_image']
                    serial_info['item_inner_count'] = i['item_inner_count']
                    serial_info['manufacturing_date'] = i['mfg_date']
                    serial_info['expiry_date'] = i['expiry_date']
                    serial_info['serial_number'] = i['package_sn']
                    serial_info['gtin'] = i['gtin']
                    if i['is_active'] == 1:
                        status = 'status is active'
                        serial_info['status'] = status
                    else:
                        status = 'status is in-active'
                        serial_info['status'] = status


    result = [{'serial_info': serial_info}]
    return jsonify({'message': 'no records found'} if serial_info == {} else result)


#################################### lot info ###########################
@app.route('/api/v1/product/identification/lot/info/<string:gtin>')
def lot_info_details(gtin):
    lot_info_data = requests.get('http://3.86.246.56:5000/api/micro/v1/product/lot/info').json()

    serial_list = []
    lot_info = {}
    for i in lot_info_data['lot_info']:
        if gtin == i['gtin']:
            if request.args:
                lot_num = request.args.get('lotNumber')
                if lot_num == i['batch_no']:

                    lot_info['lot_number'] = i['batch_no']
                    lot_info['company_gln'] = i['company_gln']
                    lot_info['company_name'] = i['company_name']
                    lot_info['mfg_address'] = i['mfg_address']
                    lot_info['expiry_date'] = i['expiry_date']
                    lot_info['manufacturing_date'] = i['mfg_date']
                    lot_info['quantiy'] = i['lot_qty']
                    if i['is_active'] == 1:
                        status = 'lot is active'
                        lot_info['status'] = status
                    else:
                        status = 'lot is inactive'
                        lot_info['status'] = status

                    serial_info_data = requests.get(
                        'http://3.86.246.56:5000/api/micro/v1/package/item-information').json()
                    for i in serial_info_data['item_information']:
                        if i['gtin'] == gtin and i['batch_no'] == lot_num:
                            serial_list.append(i['package_sn'])
    lot_info['serial_list'] = serial_list

    result = [{'lot_info': lot_info}]
    return jsonify({'message': 'no records found'} if lot_info == {} else result)


####################################################################################
# Package info
##################################################################################

################list of sscc ########################
@app.route('/api/v1/package/identification/sscc/list')
def sscc_list():
    sscc_url_data = requests.get('http://3.86.246.56:5000/api/micro/v1/package/sscc/list').json()
    sscc_list_data = []
    for i in sscc_url_data['lot_info']:
        sscc_list_data.append(i['sscc_no'])

    result = [{'sscc_list': sscc_list_data}]
    return jsonify({'message': 'no records found'} if sscc_list_data == [] else result)


################################## SSCC INFO ##########################################

@app.route('/api/v1/package/identification/sscc/info/<string:sscc>')
def sscc_info(sscc):
    sscc_info_url = requests.get('http://3.86.246.56:5000/api/micro/v1/package/sscc/info').json()
    sscc_info_data = {}
    for i in sscc_info_url['lot_info']:
        if sscc == i['sscc_no']:
            sscc_info_data['sscc_no'] = i['sscc_no']
            sscc_info_data['package_type'] = i['package_type']
            sscc_info_data['shape'] = i['shape']
            sscc_info_data['total_dimensions'] = i['total_dimensions']
            sscc_info_data['width'] = i['width']
            sscc_info_data['inner_serail_list'] = i['inner_serail_list']
            sscc_info_data['inner_serail_count'] = i['inner_serail_count']
            sscc_info_data['depth'] = i['depth']
            sscc_info_data['is_active'] = i['is_active']
            sscc_info_data['package_gross_weight'] = i['package_gross_weight']
            sscc_info_data['total_dimensions'] = i['total_dimensions']
            if i['is_active'] == 1:
                status = 'transaction is active state'
                sscc_info_data['Package_status'] = status
            else:
                status = 'transaction is inactive state'
                sscc_info_data['Package_status'] = status

    result = [{'sscc_list': sscc_info_data}]
    return jsonify({'message': 'no records found'} if sscc_info_data == {} else result)


################### track with serial and gtin ################
@app.route('/api/v3/product/track/items/<string:gtin>')
def item_track_gtin_serial(gtin):
    t1 = time.time()
    track_info = requests.get('http://3.86.246.56:5000/api/v2/product/track/item_sys').json()
    main_data = []
    item = {}
    owner_data = {}
    entry_point = {}
    exit_point = {}
    controll_condition = {}
    owner_data_location = {}
    location = {}
    entry_point_location = {}
    exit_point_location = {}
    transaction_event = {}
    transaction_status = {}
    for i in track_info['track_info']:
        if i['item_info']['gtin'] == gtin:
            if request.args:
                serial_num = request.args.get('serialNumber')
                # lot_num = request.args.get('lotNumber')
                if serial_num == i['item_info']['package_sn']:

                    item['lot_number'] = i['item_info']['batch_no']
                    item['product_name'] = i['item_info']['product_name']
                    item['brand'] = i['item_info']['brand_name']
                    item['expiry_date'] = i['item_info']['expiry_date']
                    item['manufacturing_date'] = i['item_info']['mfg_date']
                    item['package_type'] = i['item_info']['item_pack_type']
                    item['quantity'] = i['item_info']['item_inner_count']
                    item['serial_number'] = i['item_info']['package_sn']
                    if i['item_info']['is_active'] == 1:
                        item['status'] = 'transaction status is active'
                    else:
                        item['status'] = 'transaction status is in-active'

                    current_owner = requests.get(i['current_owner']).json()
                    owner = current_owner['package_transaction']
                    for j in owner:
                        if serial_num == j['package_sn']:
                            owner_data['current_owner'] = j['current_owner_name']
                            entry_point['owner'] = j['entry_point_owner']
                            entry_point['address'] = j['entry_point_owner_location']

                            exit_point['comapny_name'] = j['exit_point_owner']
                            exit_point['company_address'] = j['exit_point_owner_location']

                            transaction_event['handoff_event'] = j['transaction_timestamp']
                            transaction_status['transaction_status'] = j['item_status']

                    current_location = requests.get(i['current_location']).json()
                    location_curr = current_location['transaction']
                    for k in location_curr:
                        if serial_num == k['package_sn']:
                            owner_data['gln'] = k['company_gln']
                            location['current_lat'] = k['current_lat']
                            location['current_long'] = k['current_long']
                            owner_data['current_owner_address'] = k['current_owner_address_id']

                            entry_point_location['latitude'] = k['entry_lat']
                            entry_point_location['longitude'] = k['entry_long']
                            entry_point['gln'] = k['entry_point_gln']

                            exit_point_location['latitude'] = k['exit_latitude']
                            exit_point_location['longitude'] = k['exit_long']
                            exit_point['gln'] = k['exit_point_gln']

                            controll_condition['temperature'] = k['temperature']
                            controll_condition['humidity'] = k['humidity']

    t2 = time.time()
    time_1 = ("Elasped Time(Sec): ", round(t2 - t1, 5), "sec")
    result = {'pack_info': item, 'Respose time': time_1, 'owner_info': owner_data, 'exit_point': exit_point,
              'entry_point': entry_point,
              'current_location': location, 'entry_point_location': entry_point_location,
              'exit_point_location': exit_point_location,
              'transaction_status': transaction_status, 'transaction_event': transaction_event,
              'controll_conditions': controll_condition}
    return jsonify({'message': 'Sorry! No records available'} if item == {} else result)

#######################################################################################################################################
                                                  # TRACE MICROSERVICE
###################################################################################################################################

##############current owner ########################
@app.route('/api/micro/v1/product/current_owner-info')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def current_owner_info():
    owner_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT product_gtin,batch_no,package_sn, current_owner_name, current_owner_gln,id,current_owner_address  FROM  vw_item_transactions_trace")
    current_owner_data = cursor.fetchall()

    result = [{'current_owner': current_owner_data}]
    return jsonify(result)
    cursor.close()

    conn.close()
######## current owner event _ status (ASP,Intransit, Delivred)#########

@app.route('/api/micro/v1/product/current_owner-status')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def current_owner_status():
    owner_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT product_gtin,batch_no,package_sn, current_owner_gln, id, event_type FROM  vw_item_transactions_trace")
    current_owner_status_data = cursor.fetchall()

    result = [{'current_owner_status': current_owner_status_data}]
    return jsonify(result)
    cursor.close()

    conn.close()


######################## previous owner (name and GLN)###############################

@app.route('/api/micro/v1/owner/previous_owner')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def previous_owner_status():
    owner_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT product_gtin,batch_no,package_sn,name_sender,sender_address, from_gln FROM  vw_item_transactions_trace")
    previous_current_owner = cursor.fetchall()

    result = [{'previous_owner': previous_current_owner}]
    return jsonify(result)
    cursor.close()

    conn.close()

###################entry point owner name and adress ################################

@app.route('/api/micro/v1/owner/entry_point')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def entry_point_owner():
    owner_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT product_gtin,batch_no,package_sn,entry_point_owner,entry_point_owner_location FROM  vw_item_transactions_trace")
    entry_point = cursor.fetchall()

    result = [{'entry_point': entry_point}]
    return jsonify(result)
    cursor.close()

    conn.close()

##################################Exit poin name and adress ###################################
@app.route('/api/micro/v1/owner/exit_point')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def exit_point_owner():
    owner_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT product_gtin,batch_no,package_sn,exit_point_owner,exit_point_owner_location FROM  vw_item_transactions_trace")
    exit_point = cursor.fetchall()

    result = [{'exit_point': exit_point}]
    return jsonify(result)
    cursor.close()

    conn.close()

############owners gln ########
@app.route('/api/micro/v1/owners/glns')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def gln_info():
    owner_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin, package_sn, entry_point_gln, exit_point_gln, package_sn company_gln FROM  vw_location_summary")
    gln_data = cursor.fetchall()

    result = [{'gln_data': gln_data}]
    return jsonify(result)
    cursor.close()

    conn.close()

################ transaction ##############################


@app.route('/api/micro/v1/owners/transaction')
def transaction_info():
    owner_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace")
    transaction_data = cursor.fetchall()

    result = [{'transactions': transaction_data}]
    return jsonify(result)
    cursor.close()

    conn.close()

##########location summary###########

@app .route('/api/micro/v1/owners/location_summary')
def location_info():
    owner_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  location_summary")
    location_data = cursor.fetchall()
    owner_info['location'] = location_data

    result = [owner_info]
    return jsonify(result)
    cursor.close()

    conn.close()
######################################################
@app.route('/api/v2.1.0/exp/product/track/item/<string:gtin>')
def track_exp(gtin):
    t1 = time.time()
    track_info = requests.get('http://3.86.246.56:5000/api/v2/product/track/item_sys').json()
    unit = []
    f_item = []
    f_locations = []
    f_controll_conditions = []
    f_owners = []
    f_transaction_event = []
    f_transaction_status = []
    f_person = []
    f_department = []
    f_lot = []
    f_gtin = []

    person = {}
    deptartment = {}
    item = {}
    owner_data = {}
    entry_point = {}
    exit_point = {}
    controll_condition = {}
    owner_data_location = {}
    location = {}
    entry_point_location = {}
    exit_point_location = {}
    transaction_event = {}
    transaction_status = {}
    gtin_info = {}
    lot_info = {}
    item_info = {}

    for i in track_info['track_info']:
        if i['item_info']['gtin'] == gtin:
            if request.args:
                serial_num = request.args.get('serialNumber')
                lot_num = request.args.get('lotNumber')
                if serial_num == i['item_info']['package_sn'] and lot_num == i['item_info']['batch_no']:

                    gtin_info['product_name'] = i['item_info']['product_name']
                    gtin_info['brand'] = i['item_info']['brand_name']
                    item['package_type'] = i['item_info']['item_pack_type']
                    item['quantity'] = i['item_info']['item_inner_count']
                    item['serial_number'] = i['item_info']['package_sn']
                    lot_info['expiry_date'] = i['item_info']['expiry_date']
                    lot_info['manufacturing_date'] = i['item_info']['mfg_date']
                    lot_info['lot_total_qty'] = i['item_info']['lot_total_qty']
                    lot_info['lot_number'] = i['item_info']['batch_no']
                    gtin_info['serial_number'] = i['item_info']['company_name']
                    gtin_info['serial_number'] = i['item_info']['company_gln']

                    if i['item_info']['is_active'] == 1:
                        item['status'] = 'transaction status is active'
                    else:
                        item['status'] = 'transaction status is in-active'

                    current_owner = requests.get(i['current_owner']).json()
                    owner = current_owner['package_transaction']
                    for j in owner:
                        if serial_num == j['package_sn'] and lot_num == j['batch_no']:
                            owner_data['current_owner'] = j['current_owner_name']
                            entry_point['owner'] = j['entry_point_owner']
                            entry_point['address'] = j['entry_point_owner_location']

                            exit_point['comapny_name'] = j['exit_point_owner']
                            exit_point['company_address'] = j['exit_point_owner_location']

                            transaction_event['handoff_event'] = j['transaction_timestamp']
                            transaction_status['transaction_status'] = j['item_status']


                    current_location = requests.get(i['current_location']).json()
                    location_curr = current_location['transaction']
                    for k in location_curr:
                        if serial_num == k['package_sn']:
                            owner_data['gln'] = k['company_gln']
                            location['current_lat'] = k['current_lat']
                            location['current_long'] = k['current_long']
                            owner_data['current_owner_address'] = k['current_owner_address_id']
                            deptartment['name'] = 'packing'
                            # deptartment['id'] = 3
                            # person['id'] = 2546
                            # person['name'] =

                            entry_point_location['latitude'] = k['entry_lat']
                            entry_point_location['longitude'] = k['entry_long']
                            entry_point['gln'] = k['entry_point_gln']

                            exit_point_location['latitude'] = k['exit_latitude']
                            exit_point_location['longitude'] = k['exit_long']
                            exit_point['gln'] = k['exit_point_gln']

                            controll_condition['temperature'] = k['temperature']
                            controll_condition['humidity'] = k['humidity']

    f_locations.append({'current_location': location})
    f_locations.append({'entry_point_location': entry_point_location})
    f_locations.append({'exit_point_location': exit_point_location})

    f_controll_conditions.append({'controll_condition': controll_condition})

    f_owners.append({'entry_point_owner': entry_point})
    f_owners.append({'current_owner': owner_data})
    f_owners.append({'exit_point_ower': exit_point})

    f_transaction_event.append({'transaction_event': transaction_event})
    f_transaction_status.append({'transaction_status': transaction_status})

    f_lot.append({'lot_information': lot_info})
    f_gtin.append({'gtin_information': gtin_info})

    t2 = time.time()
    time_1 = ("Elasped Time(Sec): ", round(t2 - t1, 5), "sec")

    item['locations'] = f_locations,
    item['controll_conditions'] = f_controll_conditions,
    item['owner'] = f_owners
    item['transaction_event'] = f_transaction_event
    item['status'] = f_transaction_status
    item['lot_information'] = f_lot
    item['gtin_information'] = f_gtin

    result = {'track': item, 'response_time': time_1}
    return jsonify({'message': 'no records found'} if item == {} else result)


######################################################################################
# GTIN+ SERIAL
###################################################################################

@app.route('/api/v2.1/exp/product/item/<string:gtin>')
def qr_track_serial_gtin(gtin):
    t1 = time.time()
    track_info = requests.get('http://3.86.246.56:5000/api/v2/product/track/item_sys').json()
    unit = []
    f_item = []
    #f_locations = []
    #f_controll_conditions = []
    #f_owners = []
    #f_transaction_event = []
    #f_transaction_status = []
    f_person = []
    f_department = []
    f_lot = []
    f_gtin = []

    person = {}
    deptartment = {}
    item = {}
    owner_data = {}
    entry_point = {}
    exit_point = {}
    controll_condition = {}
    owner_data_location = {}
    location = {}
    entry_point_location = {}
    exit_point_location = {}
    transaction_event = {}
    transaction_status = {}
    gtin_info = {}
    lot_info = {}
    item_info = {}

    for i in track_info['track_info']:
        if i['item_info']['gtin'] == gtin:
            if request.args:
                serial_num = request.args.get('serialNumber')
                if serial_num == i['item_info']['package_sn']:

                    gtin_info['product_name'] = i['item_info']['product_name']
                    gtin_info['brand'] = i['item_info']['brand_name']
                    item['package_type'] = i['item_info']['item_pack_type']
                    item['quantity'] = i['item_info']['item_inner_count']
                    item['serial_number'] = i['item_info']['package_sn']
                    lot_info['expiry_date'] = i['item_info']['expiry_date']
                    lot_info['manufacturing_date'] = i['item_info']['mfg_date']
                    lot_info['lot_total_qty'] = i['item_info']['lot_total_qty']
                    lot_info['lot_number'] = i['item_info']['batch_no']
                    gtin_info['serial_number'] = i['item_info']['company_name']
                    gtin_info['serial_number'] = i['item_info']['company_gln']

                    if i['item_info']['is_active'] == 1:
                        item['status'] = 'status is active'
                        lot_info['status'] = 'status is active'
                        gtin_info['status'] = 'status is active'

                    else:
                        item['status'] = 'status is in-active'
                        lot_info['status'] = 'status is in-active'
                        gtin_info['status'] = 'status is in-active'
                    #
                    # current_owner = requests.get(i['current_owner']).json()
                    # owner = current_owner['package_transaction']
                    # for j in owner:
                    #     if serial_num == j['package_sn']:
                    #         owner_data['current_owner'] = j['current_owner_name']
                    #         owner_data['current_owner_address'] = j['current_owner_address']
                    #         entry_point['owner'] = j['entry_point_owner']
                    #         entry_point['address'] = j['entry_point_owner_location']
                    #         entry_point['latitude'] = j['entry_lat']
                    #         entry_point['longitude'] = j['entry_long']
                    #
                    #         exit_point['comapny_name'] = j['exit_point_owner']
                    #         exit_point['company_address'] = j['exit_point_owner_location']
                    #
                    #         transaction_event['handoff_event'] = j['transaction_timestamp']
                    #         transaction_status['transaction_status'] = j['item_status']
                    #
                    #
                    #
                    # current_location = requests.get(i['current_location']).json()
                    # location_curr = current_location['transaction']
                    # for k in location_curr:
                    #     if serial_num == k['package_sn']:
                    #         owner_data['gln'] = k['company_gln']
                    #         location['current_lat'] = k['current_lat']
                    #         location['current_long'] = k['current_long']
                    #         location['current_address'] = k['current_location']
                    #         deptartment['name'] = 'packing'
                    #
                    #         entry_point_location['latitude'] = k['entry_lat']
                    #         entry_point_location['longitude'] = k['entry_long']
                    #         entry_point['gln'] = k['entry_point_gln']
                    #
                    #         exit_point_location['latitude'] = k['exit_latitude']
                    #         exit_point_location['longitude'] = k['exit_long']
                    #         exit_point['gln'] = k['exit_point_gln']
                    #
                    #         controll_condition['temperature'] = k['temperature']
                    #         controll_condition['humidity'] = k['humidity']

    #f_locations.append({'current_location': location})
    #f_locations.append({'entry_point_location': entry_point_location})
    #f_locations.append({'exit_point_location': exit_point_location})

    #f_controll_conditions.append({'controll_condition': controll_condition})

    #f_owners.append({'entry_point_owner': entry_point})
    #f_owners.append({'current_owner': owner_data})
    #f_owners.append({'exit_point_ower': exit_point})

    #f_transaction_event.append({'transaction_event': transaction_event})
    #f_transaction_status.append({'transaction_status': transaction_status})

    f_lot.append({'lot_information': lot_info})
    f_gtin.append({'gtin_information': gtin_info})

    t2 = time.time()
    time_1 = ("Elasped Time(Sec): ", round(t2 - t1, 5), "sec")

    #item['locations'] = f_locations,
    #item['controll_conditions'] = f_controll_conditions,
    #item['owner'] = f_owners
    #item['transaction_event'] = f_transaction_event
    #item['status'] = f_transaction_status
    item['lot_information'] = f_lot
    item['gtin_information'] = f_gtin

    result = {'product_info': item, 'response_time': time_1}
    return jsonify({'message': 'no records found'} if item == {} else result)
###########
######################################################################################
# GTIN+ SERIAL
###################################################################################

@app.route('/api/v2.1/exp/product/track/item/<string:gtin>')
def track_serial_gtin(gtin):
    t1 = time.time()
    track_info = requests.get('http://3.86.246.56:5000/api/v2/product/track/item_sys').json()
    unit = []
    f_item = []
    f_locations = []
    f_controll_conditions = []
    f_owners = []
    f_transaction_event = []
    f_transaction_status = []
    f_person = []
    f_department = []
    f_lot = []
    f_gtin = []

    person = {}
    deptartment = {}
    item = {}
    owner_data = {}
    entry_point = {}
    exit_point = {}
    controll_condition = {}
    owner_data_location = {}
    location = {}
    entry_point_location = {}
    exit_point_location = {}
    transaction_event = {}
    transaction_status = {}
    gtin_info = {}
    lot_info = {}
    item_info = {}

    for i in track_info['track_info']:
        if i['item_info']['gtin'] == gtin:
            if request.args:
                serial_num = request.args.get('serialNumber')
                if serial_num == i['item_info']['package_sn']:

                    gtin_info['product_name'] = i['item_info']['product_name']
                    gtin_info['brand'] = i['item_info']['brand_name']
                    item['package_type'] = i['item_info']['item_pack_type']
                    item['quantity'] = i['item_info']['item_inner_count']
                    item['serial_number'] = i['item_info']['package_sn']
                    lot_info['expiry_date'] = i['item_info']['expiry_date']
                    lot_info['manufacturing_date'] = i['item_info']['mfg_date']
                    lot_info['lot_total_qty'] = i['item_info']['lot_total_qty']
                    lot_info['lot_number'] = i['item_info']['batch_no']
                    gtin_info['serial_number'] = i['item_info']['company_name']
                    gtin_info['serial_number'] = i['item_info']['company_gln']

                    if i['item_info']['is_active'] == 1:
                        item['status'] = 'status is active'
                        lot_info['status'] = 'status is active'
                        gtin_info['status'] = 'status is active'

                    else:
                        item['status'] = 'status is in-active'
                        lot_info['status'] = 'status is in-active'
                        gtin_info['status'] = 'status is in-active'

                    current_owner = requests.get(i['current_owner']).json()
                    owner = current_owner['package_transaction']
                    for j in owner:
                        if serial_num == j['package_sn']:
                            owner_data['current_owner'] = j['current_owner_name']
                            owner_data['current_owner_address'] = j['current_owner_address']
                            entry_point['owner'] = j['entry_point_owner']
                            entry_point['address'] = j['entry_point_owner_location']
                            entry_point['latitude'] = j['entry_lat']
                            entry_point['longitude'] = j['entry_long']

                            exit_point['comapny_name'] = j['exit_point_owner']
                            exit_point['company_address'] = j['exit_point_owner_location']

                            transaction_event['handoff_event'] = j['transaction_timestamp']
                            transaction_status['transaction_status'] = j['item_status']



                    current_location = requests.get(i['current_location']).json()
                    location_curr = current_location['transaction']
                    for k in location_curr:
                        if serial_num == k['package_sn']:
                            owner_data['gln'] = k['company_gln']
                            location['current_lat'] = k['current_lat']
                            location['current_long'] = k['current_long']
                            location['current_address'] = k['current_location']
                            deptartment['name'] = 'packing'

                            entry_point_location['latitude'] = k['entry_lat']
                            entry_point_location['longitude'] = k['entry_long']
                            entry_point['gln'] = k['entry_point_gln']

                            exit_point_location['latitude'] = k['exit_latitude']
                            exit_point_location['longitude'] = k['exit_long']
                            exit_point['gln'] = k['exit_point_gln']

                            controll_condition['temperature'] = k['temperature']
                            controll_condition['humidity'] = k['humidity']
    f_locations.append({'current_location': location})
    f_locations.append({'entry_point_location': entry_point_location})
    f_locations.append({'exit_point_location': exit_point_location})
    f_controll_conditions.append({'controll_condition': controll_condition})

    f_owners.append({'entry_point_owner': entry_point})
    f_owners.append({'current_owner': owner_data})
    f_owners.append({'exit_point_ower': exit_point})

    f_transaction_event.append({'transaction_event': transaction_event})
    f_transaction_status.append({'transaction_status': transaction_status})

    f_lot.append({'lot_information': lot_info})
    f_gtin.append({'gtin_information': gtin_info})

    t2 = time.time()
    time_1 = ("Elasped Time(Sec): ", round(t2 - t1, 5), "sec")

    item['locations'] = f_locations,
    item['controll_conditions'] = f_controll_conditions,
    item['owner'] = f_owners
    item['transaction_event'] = f_transaction_event
    item['status'] = f_transaction_status
    item['lot_information'] = f_lot
    item['gtin_information'] = f_gtin

    result = {'track': item, 'response_time': time_1}
    return jsonify({'message': 'no records found'} if item == {} else result)


##################
@app.route('/api/micro/v2.3.3/product/item-serial-list-count/<string:gtin>')  # /api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def item_serial_count_12(gtin):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_item_pack_type_summary WHERE gtin=%s", gtin)
    lot_data = cursor.fetchall()
    serial_num_list = []
    for i in lot_data:
        if request.args:
            lot_num = request.args.get('lotnumber')
            if lot_num == i['batch_no']:
                serial = i['package_sn']
                serial_num_list.append(serial)

        result = (
        {'list_of_serial_number': len(serial_num_list), 'gtin_number': i['gtin'], 'lot_number': i['batch_no']})

    return jsonify({'count_of_serial_number': result})
    cursor.close()
    conn.close()
#########################################################TRACK SSCC###############################
#####################################################################################
'''                                 Track SSCC                          '''


###########################################################################################
@app.route('/api/v1.0.0/exp/package/track/item/<string:sscc>')
def track(sscc):
    t1 = time.time()
    track_info = requests.get('http://3.86.246.56:5000/api/v2/product/track').json()
    f_locations = []
    f_controll_conditions = []
    f_owners = []
    f_transaction_event = []
    f_transaction_status = []
    f_package = []

    package_info = {}
    package = {}
    owner_data = {}
    entry_point = {}
    exit_point = {}
    controll_condition = {}
    owner_data_location = {}
    location = {}
    entry_point_location = {}
    exit_point_location = {}
    transaction_event = {}
    transaction_status = {}

    for i in track_info['track_info']:
        if i['package_info']['sscc_no'] == sscc:

            package['colour'] = i['package_info']['colour']
            package['depth'] = i['package_info']['depth']
            package['height'] = i['package_info']['height']
            package['inner_serail_list'] = i['package_info']['inner_serail_list']
            package['package_gross_weight'] = i['package_info']['package_gross_weight']
            package['package_pallet_sn'] = i['package_info']['package_pallet_sn']
            package['package_type'] = i['package_info']['package_type']
            package['lot_number'] = i['package_info']['batch_no']
            package['shape'] = i['package_info']['shape']
            package['sscc_no'] = i['package_info']['sscc_no']
            package['total_dimensions'] = i['package_info']['total_dimensions']
            package['width'] = i['package_info']['width']
            if i['package_info']['is_active'] == 1:
                package['status'] = 'status is active'
            else:
                package['status'] = 'status is in-active'

        current_owner = requests.get(i['current_owner']).json()
        owner = current_owner['package_transaction']

        for j in owner:
            if sscc == j['sscc_no']:
                owner_data['current_owner'] = j['current_owner']
                owner_data['current_owner_address'] = j['consigner_address']
                entry_point['owner'] = j['consigner']
                entry_point['address'] = j['consigner_address']

                exit_point['comapny_name'] = j['consignee']
                exit_point['company_address'] = j['consignee_address']

                transaction_event['handoff_event'] = j['tranc_date_time']
                transaction_status['transaction_status'] = j['event_type']

        current_location = requests.get(i['current_location']).json()
        location_curr = current_location['transaction']
        for k in location_curr:
            if sscc == k['sscc_no']:
                owner_data['gln'] = k['company_gln']
                location['current_lat'] = k['current_lat']
                location['current_long'] = k['current_long']
                location['current_address'] = k['current_location']

                entry_point_location['latitude'] = k['entry_lat']
                entry_point_location['longitude'] = k['entry_long']
                entry_point['gln'] = k['entry_point_gln']

                exit_point_location['latitude'] = k['exit_latitude']
                exit_point_location['longitude'] = k['exit_long']
                exit_point['gln'] = k['exit_point_gln']

                controll_condition['temperature'] = k['temperature']
                controll_condition['humidity'] = k['humidity']

    f_locations.append({'current_location': location})
    f_locations.append({'entry_point_location': entry_point_location})
    f_locations.append({'exit_point_location': exit_point_location})

    f_controll_conditions.append({'controll_condition': controll_condition})

    f_owners.append({'entry_point_owner': entry_point})
    f_owners.append({'current_owner': owner_data})
    f_owners.append({'exit_point_ower': exit_point})

    f_transaction_event.append({'transaction_event': transaction_event})
    f_transaction_status.append({'transaction_status': transaction_status})

    f_package.append({'package_information': package})

    t2 = time.time()
    time_1 = ("Elasped Time(Sec): ", round(t2 - t1, 5), "sec")

    package_info['locations'] = f_locations,
    package_info['controll_conditions'] = f_controll_conditions,
    package_info['owner'] = f_owners
    package_info['transaction_event'] = f_transaction_event
    package_info['status'] = f_transaction_status
    # package_info['lot_information'] = f_lot
    # package_info['gtin_information'] = f_gtin
    package_info['package_information'] = f_package

    result = {'track': package_info, 'response_time': time_1}
    return jsonify({'message': 'no records found'} if package_info == {} else result)
#############################TRACE####################################################
@app.route('/api/v1.0.0/product/trace/<string:gtin>')
def product_trace_1(gtin):
    gtin_list = requests.get('http://54.196.204.11:8083/api/v1/product/system/item_info').json()

    t1 = time.time()
    item_info = {}
    lot_info = {}
    product_info = {}

    current_owner = {}
    entry_point = {}
    exit_point = {}
    prev_owner = {}
    next_owner = {}
    current_owner_location = {}
    entry_point_location = {}
    exit_point_location = {}
    transaction_info_dict = {}

    prev_owner_lst = []
    prev_location_lst = []
    prev_transaction = []

    f_product_info = []
    f_owner = []
    f_location = []
    f_transaction = []

    for i in gtin_list:
        if i['gtin'] == gtin:
            if request.args:
                lot_num = request.args.get('lotNumber')
                serial_num = request.args.get('serialNumber')
                if i['lot_number'] == lot_num and serial_num == i['serial_number']:
                    transaction_info = requests.get(i['transaction_info']).json()
                    location_info = requests.get(i['location_info']).json()
                    product_info['brand_name'] = i['brand_name']
                    item_info['package_type'] = i['package_type']
                    item_info['image'] = i['image']
                    item_info['item_inner_count'] = i['item_inner_count']
                    lot_info['manufacturing_date'] = i['manufacturing_date']
                    lot_info['expiry_date'] = i['expiry_date']
                    item_info['serial_number'] = i['serial_number']
                    product_info['gtin'] = i['gtin']
                    #item_info['product_name'] = i['product_name']
                    lot_info['lot_number'] = i['lot_number']
                    if i['status'] == 1:
                        status_1 = 'status is active'
                        item_info['status'] = status_1
                    else:
                        status_1 = 'status is inactive'
                        item_info['status'] = status_1

                    for l in transaction_info:
                        for j in l['transactions']:
                            if serial_num == j['package_sn'] and gtin == j['product_gtin']:
                                # current_owner['all'] = j
                                #current_owner['product_name'] = j['product_name']
                                current_owner['owner_name'] = j['current_owner_name']
                                current_owner['address'] = j['current_owner_address']
                                current_owner['gln'] = j['current_owner_gln']
                                entry_point['owner_name'] = j['entry_point_owner']
                                entry_point['address'] = j['entry_point_owner_location']
                                exit_point['owner_name'] = j['exit_point_owner']
                                exit_point['owner_location'] = j['exit_point_owner_location']
                                prev_owner['name'] = j['name_sender']
                                prev_owner['address'] = j['sender_address']
                                prev_owner['gln'] = j['from_gln']
                                # next_owner['name'] = j['name_reciver']
                                # next_owner['address'] = j['reciver_address']
                                # next_owner['gln'] = j['to_gln']
                                prev_owner_lst.append(j['current_owner_name'])
                                prev_location_lst.append(
                                    {'owner_name': j['current_owner_name'],'gln': j['current_owner_gln'], 'owner_address': j['current_owner_address']})  #

                                transaction_info_dict['handoff_timestamp'] = j['transaction_timestamp']
                                transaction_info_dict['handoff_event'] = j['event_type']
                                transaction_info_dict['owner_name'] = j['current_owner_name']
                                transaction_info_dict['owner_address'] = j['current_owner_address']
                                transaction_info_dict['gln'] = j['current_owner_gln']
                                prev_transaction.append(
                                    {'gln': j['current_owner_gln'],'transaction_id': j['id'],'owner_name': j['current_owner_name'],'transaction_timestamp': j['transaction_timestamp'], 'event_type': j['event_type']}) #


                    for t in location_info:
                        for k in t['location']:
                            if serial_num == k['package_sn']:
                                # prev_owner_lst.append()
                                current_owner_location['latitude'] = k['current_lat']
                                current_owner_location['logitude'] = k['current_long']
                                entry_point_location['latitude'] = k['entry_lat']
                                entry_point_location['logitude'] = k['entry_long']
                                exit_point_location['latitude'] = k['exit_latitude']
                                exit_point_location['logitude'] = k['exit_long']
                                #transaction_info_dict['handoff_timestamp'] = k['transaction_timestamp']
                                #transaction_info_dict['handoff_event'] = k['event_type']
                                #transaction_info_dict['owner_name'] = k['current_company_name']
                                #transaction_info_dict['owner_address'] = k['current_owner_address']

    f_product_info.append({'item_inforamtion': item_info})
    f_product_info.append({'lot_information': lot_info})
    f_product_info.append({'product_information': product_info})

    f_owner.append({'current_owner': current_owner})
    f_owner.append({'entry_point': entry_point})
    f_owner.append({'exit_point': exit_point})
    #f_owner.append({'next_owner': next_owner})
    f_owner.append({'previous_owner': prev_owner})
    f_owner.append({'all_previous_owner': prev_owner_lst[:-1]})

    f_location.append({'current_owner': current_owner_location})
    f_location.append({'entry_point': entry_point_location})
    f_location.append({'exit_point': exit_point_location})
    f_location.append({'all_previous_owners_location': prev_location_lst})
    f_location.append({'latest_transaction_location': transaction_info_dict})
    f_transaction.append({'latest_transaction': transaction_info_dict})
    f_transaction.append({'previous_transactions': prev_transaction})

    f_product_info.append({'owner': f_owner})
    f_product_info.append({'location': f_location})
    f_product_info.append({'transaction': f_transaction})

    t2 = time.time()
    time_1 = ("Elasped Time(Sec): ", round(t2 - t1, 5), "sec")

    result = [{'response_time': time_1, 'trace': f_product_info}]
    return jsonify({'message': 'no records found'} if product_info == {} else result)

######################################################################################
@app.route('/api/micro/v1.0.1/owners/item_trace')
def item_trace():
    trace_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace")
    trace_data = cursor.fetchall()

    result = [{'trace': trace_data}]
    return jsonify(result)
    cursor.close()
    conn.close()



#############################
@app.route('/api/v1/product/system/item_info')
def iteminfo():

    url_data = requests.get('http://3.86.246.56:5000/api/micro/v1/package/item-information').json()
    serial_info_1 = []
    serial_info ={}
    for i in url_data['item_information']:
        serial_info_1.append({
        'lot_number':i['batch_no'],
        'brand_name': i['brand_name'],
        'package_type' : i['item_pack_type'],
        'image' : i['package_image'],
        'item_inner_count' : i['item_inner_count'],
        'manufacturing_date' : i['mfg_date'],
        'expiry_date' : i['expiry_date'],
        'serial_number' : i['package_sn'],
        'gtin': i['gtin'],
        'product_name': i['product_name'],
        'status' : i['is_active'],

        'transaction_info' : 'http://3.86.246.56:5000/api/micro/v1/owners/transaction',
        'location_info' : 'http://3.86.246.56:5000/api/micro/v1/owners/location_summary',
        'trace_item' : 'http://3.86.246.56:5000/api/micro/v1.0.1/owners/item_trace'
        })

    return jsonify({'serial_info': serial_info_1})


###############################register##################
@app.route('/login_status')
def home():
    passhash = generate_password_hash('cairocoders')
    print(passhash)
    if 'username' in session:
        username = session['username']
        return jsonify({'message': 'You are already logged in', 'username': username})
    else:
        resp = jsonify({'message': 'Unauthorized'})
        resp.status_code = 401
        return resp


@app.route('/login', methods=['POST'])
def login():
    _json = request.json
    _username = _json['username']
    _password = _json['password']
    #print(_username)
    # validate the received values
    if _username and _password:
        # check user exists
        conn = mysql.connect()
        cursor = conn.cursor(pymysql.cursors.DictCursor)

        sql = "SELECT * FROM user WHERE username=%s"
        sql_where = (_username,)

        cursor.execute(sql, sql_where)
        row = cursor.fetchone()
        username = row['username']
        password = row['password']
        if row:
            if check_password_hash(password, _password):
                session['username'] = username
                cursor.close()
                return jsonify({'message': 'You are logged in successfully'})
            else:
                resp = jsonify({'message': 'Bad Request - invalid password'})
                resp.status_code = 400
                return resp
    else:
        resp = jsonify({'message': 'Bad Request - invalid credendtials'})
        resp.status_code = 400
        return resp




@app.route('/logout')
def logout():
    if 'username' in session:
        session.pop('username', None)
    return jsonify({'message': 'You successfully logged out'})
###############################register#########
@app.route('/register', methods =['GET', 'POST'])
def register():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form and 'address' in request.form and 'city' in request.form and 'country' in request.form and 'postalcode' in request.form and 'organisation' in request.form:
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        organisation = request.form['organisation']
        address = request.form['address']
        city = request.form['city']
        state = request.form['state']
        country = request.form['country']
        postalcode = request.form['postalcode']
        conn = mysql.connect()
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user WHERE username = % s', (username, ))
        user = cursor.fetchone()
        if user:
            msg = 'Account already exists !'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address !'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'name must contain only characters and numbers !'
        else:
            cursor.execute('INSERT INTO user VALUES (NULL, % s, % s, % s, % s, % s, % s, % s, % s, % s)',(username, password, email, organisation, address, city, state, country, postalcode,))
            mysql.connection.commit()
            cursor.close()
            mysql.connection.close()
            msg = 'You have successfully registered !'
    elif request.method == 'POST':
        msg = 'Please fill out the form !'
    return msg

######################################################

######################################################

@app.route('/api/micro/v1.0.0/admin/user/list/<string:id>')  # url
def adminUserList(id):
    data = {}
    timestamp = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  api_user WHERE add_user_id = %s ",id)
    user_list = cursor.fetchall()


    result = ({"user_list": user_list})

    return jsonify(result)
    cursor.close()
    conn.close()
################# give name of the module   ###################

@app.route('/api/system/v1.0.0/admin/user/list/<string:user_id>')
def admi_UserList(user_id):
    users = []

    admin_user_data = requests.get(f"http://3.86.246.56:8003/api/micro/v1.0.0/user/list/{user_id}").json()

    for i in admin_user_data['user_list']:
        if i['is_active'] == 1:
            active_status = 'user is active'
        else:
            active_status = 'user is in-active'

        if i['is_deleted'] == 1:
            user_existed_Status == 'user is no longer member'
        else:
            user_existed_Status = 'user is a member, please check for user active status'

        ########''' for final decision ''' #########

        if i['is_active'] == 0 and i['is_deleted'] == 0:
            user_active = 'user is a member deactiveted, please check for user active status'
        elif i['is_active'] == 0 and i['is_deleted'] == 1:
            user_active = 'user is no longer member'
        else:
            user_active = 'user is not registred yet'

        # 1 = active
        # 0 = inactive

        users.append({
            'admin_id': i['add_user_id'],
            'alternate_contact_number': i['alternate_contact_number'],
            'alternate_email': i['alternate_email'],
            'contact_number': i['contact_number'],
            'created_by': i['created_by'],
            'created_date': i['created_date'],
            'date_joined': i['date_joined'],
            'designation': i['designation'],
            'email': i['email'],
            'first_name': i['first_name'],
            'user_id': i['id'],
            'last_login': i['last_login'],
            'last_name': i['last_name'],
            'modified_by': i['modified_by'],
            'modified_date': i['modified_date'],
            'organization_id': i['organization_id'],
            'user_name': i['user_name'],
            'user_active_status': user_active,

        })
    result = {'user_information': users}
    return jsonify({'message': 'user is not registred'} if users == [] else result)

#####################################################################################
'''                                 Track SSCC                          '''


###########################################################################################
@app.route('/api/v1.0.0/exp/package_details/<string:sscc>')
def track_pack(sscc):
    t1 = time.time()
    track_info = requests.get('http://3.86.246.56:5000/api/v2/product/track').json()
    f_locations = []
    f_controll_conditions = []
    f_owners = []
    f_transaction_event = []
    f_transaction_status = []
    f_package = []

    package_info = {}
    package = {}
    owner_data = {}
    entry_point = {}
    exit_point = {}
    controll_condition = {}
    owner_data_location = {}
    location = {}
    entry_point_location = {}
    exit_point_location = {}
    transaction_event = {}
    transaction_status = {}

    for i in track_info['track_info']:
        if i['package_info']['sscc_no'] == sscc:

            package['gtin'] = i['package_info']['gtin']

            package['colour'] = i['package_info']['colour']
            package['depth'] = i['package_info']['depth']
            package['height'] = i['package_info']['height']
            package['inner_serail_list'] = i['package_info']['inner_serail_list']
            package['package_gross_weight'] = i['package_info']['package_gross_weight']
            package['package_pallet_sn'] = i['package_info']['package_pallet_sn']
            package['package_type'] = i['package_info']['package_type']
            package['lot_number'] = i['package_info']['batch_no']
            package['shape'] = i['package_info']['shape']
            package['sscc_no'] = i['package_info']['sscc_no']
            package['total_dimensions'] = i['package_info']['total_dimensions']
            package['width'] = i['package_info']['width']
            if i['package_info']['is_active'] == 1:
                package['status'] = 'status is active'
            else:
                package['status'] = 'status is in-active'

        current_owner = requests.get(i['current_owner']).json()
        owner = current_owner['package_transaction']

        for j in owner:
            if sscc == j['sscc_no']:
                owner_data['current_owner'] = j['current_owner']
                owner_data['current_owner_address'] = j['consigner_address']
                entry_point['owner'] = j['consigner']
                entry_point['address'] = j['consigner_address']

                exit_point['comapny_name'] = j['consignee']
                exit_point['company_address'] = j['consignee_address']

                transaction_event['handoff_event'] = j['tranc_date_time']
                transaction_status['transaction_status'] = j['event_type']

        current_location = requests.get(i['current_location']).json()
        location_curr = current_location['transaction']
        for k in location_curr:
            if sscc == k['sscc_no']:
                owner_data['gln'] = k['company_gln']
                location['current_lat'] = k['current_lat']
                location['current_long'] = k['current_long']
                location['current_address'] = k['current_location']

                entry_point_location['latitude'] = k['entry_lat']
                entry_point_location['longitude'] = k['entry_long']
                entry_point['gln'] = k['entry_point_gln']

                exit_point_location['latitude'] = k['exit_latitude']
                exit_point_location['longitude'] = k['exit_long']
                exit_point['gln'] = k['exit_point_gln']

                controll_condition['temperature'] = k['temperature']
                controll_condition['humidity'] = k['humidity']

    f_locations.append({'current_location': location})
    f_locations.append({'entry_point_location': entry_point_location})
    f_locations.append({'exit_point_location': exit_point_location})

    f_controll_conditions.append({'controll_condition': controll_condition})

    f_owners.append({'entry_point_owner': entry_point})
    f_owners.append({'current_owner': owner_data})
    f_owners.append({'exit_point_ower': exit_point})

    f_transaction_event.append({'transaction_event': transaction_event})
    f_transaction_status.append({'transaction_status': transaction_status})

    f_package.append({'package_information': package})

    t2 = time.time()
    time_1 = ("Elasped Time(Sec): ", round(t2 - t1, 5), "sec")

    package_info['locations'] = f_locations,
    package_info['controll_conditions'] = f_controll_conditions,
    package_info['owner'] = f_owners
    package_info['transaction_event'] = f_transaction_event
    package_info['status'] = f_transaction_status
    # package_info['lot_information'] = f_lot
    # package_info['gtin_information'] = f_gtin
    package_info['package_information'] = f_package

    result = {'track': package_info, 'response_time': time_1}
    return jsonify({'message': 'no records found'} if package_info == {} else result)




#######
if __name__ == "__main__":
    #app.run(host=app.config['api.tracepharm.io'],port=5000,debug=True)
    app.run(host='0.0.0.0', debug=True)