import pymysql
from flask import request, jsonify  # joson format 
from flaskext.mysql import MySQL
from flask import Flask
from flask_cors import CORS, cross_origin

app = Flask(__name__)
CORS(app)

'''DATABSE_CONNECTION'''

mysql = MySQL()
app.config['MYSQL_DATABASE_HOST'] = '54.236.245.46'
app.config['MYSQL_DATABASE_USER'] = 'phpmyadmin'
app.config['MYSQL_DATABASE_PASSWORD'] = 'Admin@123'
app.config['MYSQL_DATABASE_DB'] = 'TracePharmVersion1'
mysql.init_app(app)

#########################################################

'''LIST OF GTINS'''

@app.route('/microservices/v1.0.0/product/gtin/list')
def gtin_list():
    lst = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin FROM gtin_summary")
    gtin = cursor.fetchall()
    for i in gtin:
        lst.append(i['gtin'])
    result = {'gtin-list': lst}
    return jsonify(result)
    cursor.close() 
    conn.close()


################################################
'''GTIN COUNTS '''
################################################

@app.route('/microservices/v1.0.0/products/gtins/counts')
def gtin_count():
    gtin_list = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin FROM gtin_summary")
    gtin = cursor.fetchall()
    for i in gtin:
        gtin_list.append(i['gtin'])
    
    result = len(gtin_list)
    return jsonify({'gtin_count':result})
    cursor.close() 
    conn.close()
################################################################
'''active and inactive GTIN'''
##############################################################

@app.route('/microservices/v1.0.0/products/gtins/status/<string:gtin>')
def gtin_status(gtin):
    gtin_status = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin, is_active, id FROM gtin_summary WHERE gtin=%s",gtin)
    gtin_data = cursor.fetchall()
    for i in gtin_data:
        gtin_status['id'] = i['id']
        gtin_status['gtin_number'] = i['gtin']
        if i['is_active'] == 1:
            status = 'Gtin status is active'
            gtin_status['gtin_status'] = status
        else:
            status = 'Gtin status is in-active'
            gtin_status['gtin_status'] = status
                
    result = {'status':gtin_status}
    return jsonify(result)
    cursor.close() 
    conn.close()
###############################################
'''gtin active inactive status list'''
##########################################

@app.route('/microservices/v1.0.0/products/gtins/statuslist/')
def active_inactive_gtins():
    gtin_status = {}
    active_status = []
    inactive_status = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin, is_active, id FROM gtin_summary")
    gtin_data = cursor.fetchall()
    for i in gtin_data:
        # gtin_status['id'] = i['id']
        # gtin_status['gtin_number'] = i['gtin']
        if i['is_active'] == 1:
            gtin_status['id'] = i['id']
            gtin_status['gtin_number'] = i['gtin']
            active_status.append(gtin_status)
        else:
            gtin_status['id'] = i['id']
            gtin_status['gtin_number'] = i['gtin']
            inactive_status.append(gtin_status)
                
    result = {'active_status':active_status, 'inactive_status':inactive_status}
    return jsonify(result)
    cursor.close() 
    conn.close()
#########################################
'''gtin_info'''
###################################

@app.route('/microservices/v1.0.0/products/gtins/information/<string:gtin>')
def gtin_info(gtin):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_summary WHERE gtin=%s",gtin)
    gtin = cursor.fetchall()
                
    result ={'gtin_info': gtin}
    return jsonify(result)
    cursor.close() 
    conn.close()
##########################################
#########################################

'''             LOT MICROSERVICES                  '''

################################################################
'''                List of lot              '''
##############################################
@app.route('/microservices/v1.0.0/products/lot/list/<string:gtin>')
def lot_list(gtin):
    lot_list = []
    lot_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin, batch_no, id FROM gtin_lot_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()

    for i in lot_data:
        lot_list.append({'lot_id':i['id'], 'lot_info':i['batch_no'], 'gtin':i['gtin']})

    # result = [{'lot_list':lot_list}]
    return jsonify({'lot_list':lot_list})
    cursor.close() 
    conn.close()
########################################################

'''  LOT INFORMATION  '''
#############################


@app.route('/microservices/v1.0.0/products/lot/information/<string:gtin>')
def lot_info(gtin):

    lotinfo = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()

    for i in lot_data:

        lotinfo['lot_information'] =  i

    result =(lotinfo)
    return jsonify(result)
    cursor.close()
    conn.close()
####################################

@app.route('/microservices/v1.0.0/products/lot/status/<string:gtin>')
def lot_status(gtin):
    lotinfo = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin, batch_no,is_active FROM gtin_lot_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()
    for i in lot_data:
        if request.args:
            lot_num = request.args.get('lotNumber')
            if gtin == i['gtin'] and lot_num == i['batch_no']:
                lotinfo['gtin_number'] = i['gtin']
                lotinfo['lot_number'] = i['batch_no']
                if i['is_active'] == 1:
                    status_info = 'lot status is active'
                    lotinfo['status'] = status_info
                else:
                    status_info = 'lot status is inactive'
                    lotinfo['status'] = status_info
    result =(lotinfo)

    return jsonify({'message':'please enter correct information'} if lotinfo =={} else result)
    cursor.close()
    conn.close()

###########################################

''' ITEM INFORMATION  '''

###########################

################################
''' LIST OF SERIAL NUMBER '''
############################
@app.route('/microservices/v1.0.0/products/items/serialList/<string:gtin>') #api/micro/v1/product/item-serial-list?lotnumber= 12345
def serial_num_list(gtin):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_item_pack_type_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()
    serial_num = []
    for i in lot_data:
        if request.args:
            lot_num = request.args.get('lotNumber')
            if gtin == i['gtin'] and lot_num == i['batch_no']:
                serial_num.append({'serial_number': i['package_sn'], 'id' :i['id']})

    result =({'list_of_serial_number':serial_num})

    return jsonify({'message':'please enter corrent information'} if serial_num ==[] else result)
    cursor.close()
    conn.close()
#####################################
''' count of serial number '''
#####################################

@app.route('/microservices/v1.0.0/product/item/serialCount/<string:gtin_1>')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def item_serial_count_12(gtin_1):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT package_sn, id, batch_no, gtin  FROM gtin_lot_item_pack_type_summary WHERE gtin=%s",gtin_1)
    lot_data = cursor.fetchall()
    serial_num = []
    for i in lot_data:
        if request.args:
            lot_num = request.args.get('lotNumber')
            if gtin_1 == i['gtin'] and lot_num == i['batch_no']:
                serial_num.append({'serial_number': i['package_sn'], 'id' :i['id']})

    result =({'list_of_serial_number':len(serial_num), 'gtin_number': i['gtin'],'lot_number': i['batch_no']})

    return jsonify({'message':'please enter corrent information'} if serial_num ==[] else result)
    cursor.close()
    conn.close()
###################################
    '''  item Information '''
##################################
@app.route('/microservices/v1.0.0/product/item/information/<string:gtin>')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def serial_num_info(gtin):
    serial_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_item_pack_type_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()
    for i in lot_data:
        if request.args:
            lot_num = request.args.get('lotNumber')
            serial_num = request.args.get('serialNumber')
            if lot_num == i['batch_no'] and serial_num == i['package_sn']:
                serial_info['serial_information'] = i
    result =({'list_of_serial_number':serial_info})
    return jsonify({'message':'please enter corrent information'} if serial_info =={} else result)
    cursor.close()
    conn.close()
###########################
''' Serial Number Status '''
###################

@app.route('/microservices/v1.0.0/product/items/status/<string:gtin>')                                                       # url
def unit_status(gtin):
    item = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_item_pack_type_summary WHERE gtin=%s",gtin)
    item_data = cursor.fetchall()
    for i in item_data:
    #     if request.args:
            lot_num = request.args.get('lotNumber')
            serial_num = request.args.get('serialNumber')
            if gtin == i['gtin'] and lot_num == i['batch_no'] and serial_num == i['package_sn']:
                item['gtin_number'] = i['gtin']
                item['lot_number'] = i['batch_no']
                item['serial_number'] = i['package_sn']
                item['id'] = i['id']
                if i['is_active'] == 1:
                    item['status'] = 'serial_number status is in active'
                else:
                    item['status'] = 'serial_number is status is in inactive'
    result =({'iteminfo':item})
    return jsonify( result)
    cursor.close()
    conn.close()

###############################

###############################

##############################
''' package information '''
##############################
######################
''' package category '''


#########################

@app.route('/microservices/v1.0.0/packages/category/<string:sscc>')  # /api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def sscc_category(sscc):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT  gtin, batch_no, sscc_no, package_type FROM vw_package WHERE sscc_no=%s", sscc)
    package_data = cursor.fetchall()
    package_cat = []
    sscc_info = {}
    for i in package_data:
        if i['sscc_no'] == sscc:
            sscc_info['gtin_number'] = i['gtin']
            sscc_info['lot_number'] = i['batch_no']
            sscc_info['sscc_number'] = i['sscc_no']
            sscc_info['package_category'] = i['package_type']

    result = ({'package_category': sscc_info})
    return jsonify({'message': 'SSCC number is not available'} if sscc_info == {} else result)
    cursor.close()
    conn.close()


###############################
''' PACKAGE INFORMATION'''


##############################

@app.route('/microservices/v1.0.0/packages/information/<string:sscc>')  # /api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def sscc_inofrmation(sscc):
    sscc_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_package WHERE sscc_no=%s", sscc)
    package_data = cursor.fetchall()

    for i in package_data:
        sscc_info['package_information'] = i

    return jsonify({'message': 'SSCC number is not available'} if sscc_info == {} else sscc_info)
    cursor.close()
    conn.close()


############################
''' inner serial list'''


###########################

@app.route('/microservices/v1.0.0/packages/inner_content/<string:sscc>')  # /api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def package_innerlist(sscc):
    sscc_info = {}
    # inner_serial = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT id, sscc_no, inner_serail_list  FROM vw_package WHERE sscc_no=%s", sscc)
    package_data = cursor.fetchall()
    for i in package_data:
        sscc_info['sscc_no'] = i['sscc_no']
        sscc_info['id'] = i['id']
        sscc_info['package_inner_list'] = i['inner_serail_list']

    result = {'innerlist information': sscc_info}
    return jsonify({'message': 'SSCC number is not available'} if sscc_info == {} else result)
    cursor.close()
    conn.close()


####################
'''PACKAGE CURRENT LOCATION'''
####################
'''GTIN and SSCC number acceptable'''


@app.route('/microservices/v1.0.0/location/current/geoLocation/<string:sscc>')  # /api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def package_current_geo(sscc):
    currentlocation_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT company_gln, current_lat, current_long, sscc_no, id, gtin  FROM vw_location_summary WHERE sscc_no=%s or gtin=%s ",(sscc, sscc))
    location_data = cursor.fetchall()
    for i in location_data:
        if sscc == i['sscc_no'] or sscc == i['gtin']:
            currentlocation_info['id'] = i['id']
            currentlocation_info['current_latitude'] = i['current_lat']
            currentlocation_info['current_longitude'] = i['current_long']
            currentlocation_info['sscc_number'] = i['sscc_no']
            currentlocation_info['gtin_number'] = i['gtin']

    return jsonify({'message': 'SSCC number is not available'} if currentlocation_info == {} else currentlocation_info)
    cursor.close()
    conn.close()


#######################################
# current location
######################################
@app.route('/microservices/v1.0.0/location/current/location/<string:sscc>')  # /api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def package_currentlocation(sscc):
    currentlocation_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT company_gln, sscc_no, id, gtin, current_location FROM vw_location_summary WHERE sscc_no=%s or gtin=%s ",(sscc, sscc))
    location_data = cursor.fetchall()
    for i in location_data:
        if sscc == i['sscc_no'] or sscc == i['gtin']:
            currentlocation_info['id'] = i['id']
            currentlocation_info['current_comapany_gln'] = i['company_gln']
            currentlocation_info['current_comapany_address'] = i['current_location']
            currentlocation_info['sscc_number'] = i['sscc_no']
            currentlocation_info['gtin_number'] = i['gtin']

    return jsonify({'message': 'SSCC number is not available'} if currentlocation_info == {} else currentlocation_info)
    cursor.close()
    conn.close()


################################# previous location ##############################


@app.route('/microservices/v1.0.0/location/history/<string:sscc>')  # /api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def previous_location(sscc):
    all_location_info = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT id, gtin, current_lat, current_long, company_gln FROM vw_location_summary WHERE sscc_no= %s or gtin=%s",(sscc, sscc))
    location_data = cursor.fetchall()

    return jsonify({'message': 'SSCC number is not available'} if all_location_info == None else location_data)
    cursor.close()

    conn.close()
###########################################################
##################################################
'''                 CURRENT OWNER        '''
#################################################

@app.route('/microservices/v1.0.0/Owner/current/owner/<string:sscc>')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def current_owner_info(sscc):
    owner_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_item_transactions WHERE sscc_no =%s or product_gtin=%s",(sscc,sscc))
    location_data = cursor.fetchall()
    for i in location_data:
        owner_info['current_owner_gln'] = i['current_owner_gln']
        owner_info['gtin'] = i['product_gtin']
        owner_info['serial'] = i['package_sn']
        owner_info['id'] = i['id']
        owner_info['current_owner'] = i['current_owner_name']
    result = [{'current_owner': owner_info}]
    return jsonify({'message': 'SSCC number is not available'}if owner_info == {} else owner_info)
    cursor.close()
    conn.close()


###############################################################################
if __name__ == "__main__":
    app.run(host='0.0.0.0',port=8002,debug=True)