import pymysql
from flask import request, jsonify  # joson format
from flaskext.mysql import MySQL
from flask import Flask
from flask_cors import CORS, cross_origin
##################################
from pandas.tests.scalar import timestamp

app = Flask(__name__)
CORS(app)
###################################

''' Database Connection '''

mysql = MySQL()
app.config['MYSQL_DATABASE_HOST'] = '54.236.245.46'
app.config['MYSQL_DATABASE_USER'] = 'phpmyadmin'
app.config['MYSQL_DATABASE_PASSWORD'] = 'Admin@123'
app.config['MYSQL_DATABASE_DB'] = 'TracePharmVersion1'
mysql.init_app(app)

######################################################################
'''                         Micro-servics                    '''
######################################################################

@app.route('/api/micro/v1.0.0/product/gtin/list')
def gtin_list():
    lst = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin FROM gtin_summary")
    gtin = cursor.fetchall()
    for i in gtin:
        lst.append(i['gtin'])
    result = {'gtin-list': lst}
    return jsonify(result)
    cursor.close()
    conn.close()

################## Gtin Status ##################

@app.route('/api/micro/v1.0.0/product/gtin/status/<string:gtin>')
def gtin_is_active(gtin):
    gtin_status = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT id, gtin, is_active FROM gtin_summary WHERE gtin=%s",gtin)
    gtin_data = cursor.fetchall()
    for i in gtin_data:
        gtin_status['id'] = i['id']
        gtin_status['gtin_number'] = i['gtin']
        if i['is_active'] == 1:
            status = 'Gtin number status is active'
            gtin_status['gtin_status'] = status
        else:
            status = 'Gtin number status is in-active'
            gtin_status['gtin_status'] = status

    result = {'status':gtin_status}
    return jsonify(result)
    cursor.close()
    conn.close()
##################### GTIN INFORMATION #######################

@app.route('/api/micro/v1.0.0/product/gtin/info/<string:gtin>')
def gtin_info(gtin):

    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_summary WHERE gtin=%s",gtin)
    gtin = cursor.fetchall()

    result ={'gtin_info': gtin }
    return jsonify(result)
    cursor.close()
    conn.close()

################################################################################################
'''                             LOT MICROSRVICES                 '''
#################################################################################################

############list of the lot wrt gtin ###########

@app.route('/api/micro/v1.0.0/product/lot/list/<string:gtin>')
def lot_list(gtin):
    lot_list = []
    lot_info = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT id, batch_no, gtin FROM gtin_lot_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()
    for i in lot_data:
        lot_list.append({'lot_id':i['id'], 'lot_info':i['batch_no'], 'gtin_number':i['gtin']})
    return jsonify({'lot_list':lot_list})
    cursor.close()
    conn.close()

############ LOT STATUS ###########

@app.route('/api/micro/v1.0.0/product/lot/status/<string:gtin>')
def lot_status(gtin):
    lotinfo = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin, id, batch_no, is_active  FROM gtin_lot_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()

    for i in lot_data:

        if request.args:
            lot_num = request.args.get('lotNumber')

            if gtin == i['gtin'] and lot_num == i['batch_no']:
                lotinfo['id'] = i['id']
                lotinfo['gtin_number'] = i['gtin']
                lotinfo['lot_number'] = i['batch_no']
                if i['is_active'] == 1:
                    lotinfo['status'] = 'lot status is active'
                elif i['is_active'] == 0:
                    lotinfo['status'] = 'lot status is inactive'

    result = (lotinfo)

    return jsonify({'message': 'please enter correct information'} if lotinfo == {} else result)
    cursor.close()
    conn.close()
#################   LOT INFORMATION  ####################
#
# @app.route('/api/micro/v1.0.0/product/lot/info/<string:gtin>')
# def lot_info(gtin):
#     conn = mysql.connect()
#     cursor = conn.cursor(pymysql.cursors.DictCursor)
#     cursor.execute("SELECT * FROM gtin_lot_summary WHERE gtin=%s",gtin)
#     lot_data = cursor.fetchall()
#
#     result =({'lot_information':lot_data})
#     return jsonify(result)
#     cursor.close()
#     conn.close()

@app.route('/api/micro/v1.0.0/product/lot/info/<string:gtin>')
def lot_info(gtin):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_summary WHERE gtin=%s", gtin)
    lot_data = cursor.fetchall()
    print(lot_data)

    lot_dat = {}
    if request.args:
        lot_num = request.args.get('lotNumber')

    for i in lot_data:
        if i['gtin'] == gtin and i['batch_no'] == lot_num:
            lot_dat['lot_information'] = i

    result = lot_dat
    return jsonify(result)
    cursor.close()
    conn.close()


###########################################################################
'''                             ITEM MICROSRVICES                   '''
###########################################################################

###########   ITEM LIST ##########################

@app.route('/api/micro/v1.0.0/product/item/list/<string:gtin>') #api/micro/v1/product/item-serial-list?lotnumber= 12345
def serial_num_list(gtin):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_item_pack_type_summary WHERE gtin=%s",gtin)
    lot_data = cursor.fetchall()

    serial_num_list = []

    for i in lot_data:

        if request.args:
            lot_num = request.args.get('lotnumber')

            if gtin == i['gtin'] and lot_num == i['batch_no']:
                serial_num_list.append({'serial_number': i['package_sn'],
                'id' :i['id'],
                'gtin':i['gtin'],
                'lot_number':i['batch_no']})

    result =({'list_of_serial_number':serial_num_list})

    return jsonify({'message': 'please enter correct information'} if serial_num_list ==[] else result)
    cursor.close()
    conn.close()

############## ITEM iNFORMATION ####################


@app.route('/api/micro/v1.0.0/product/item/info/<string:gtin>')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def serial_num_info(gtin):
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_item_pack_type_summary WHERE gtin=%s",gtin)
    item_data = cursor.fetchall()

    for i in item_data:
        if request.args:
            lot_num = request.args.get('lotnumber')
            if lot_num == i['batch_no']:
                serial = i

    result =({'item_information':serial})

    return jsonify(result)
    cursor.close()
    conn.close()

############################## ITEM STATUS  ######################

@app.route('/api/micro/v1.0.0/product/item/status/<string:gtin>')                                                       # url
def item1_status(gtin):
    iteminfo = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM gtin_lot_item_pack_type_summary WHERE gtin=%s",gtin)
    item_data = cursor.fetchall()

    for i in item_data:
        if request.args:
            lot_num = request.args.get('lotnumber')
            serial_num = request.args.get('serial_number')
            if gtin == i['gtin'] and lot_num == i['batch_no'] and serial_num == i['package_sn']:
                iteminfo['gtin_number'] = i['gtin']
                iteminfo['lot_number'] = i['batch_no']
                iteminfo['serial_number'] = i['package_sn']
                iteminfo['id'] = i['id']
                if i['is_active'] == 1:
                    status_info = 'serial_number status is in active'
                    iteminfo['status'] = status_info
                else:
                    status_info = 'serial_number is status is in inactive'
                    iteminfo['status'] = status_info
    result =({"item_status":iteminfo})

    return jsonify({'message':'please enter correct  information'} if iteminfo =={} else result)
    cursor.close()
    conn.close()

#############################################################################
'''                                 ITEM OWNER AND LOCATION             ''' 
##############################################################################

########### ITEM  CURRENT OWNER ###############

@app.route('/api/micro/v1.0.0/item/current/owner/<string:gtin>')                                                       # url
def current_item_owner(gtin):
    item_owner = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT current_owner_name, product_gtin, batch_no, package_sn FROM vw_item_transactions_trace WHERE product_gtin=%s",gtin)
    previous_owner_data = cursor.fetchall()

    for i in previous_owner_data:
        if request.args:
            lot_num = request.args.get('lotnumber')
            serial_num = request.args.get('serial_number')
            if gtin == i['product_gtin'] and lot_num == i['batch_no'] and serial_num == i['package_sn'] :
                item_owner['owner_name'] = i['current_owner_name']
                item_owner['gtin_number'] = i['product_gtin']
                item_owner['lot_number'] = i['batch_no']
                item_owner['serial_number'] = i['package_sn']
                # item_owner['owner_name'] = i['']
    result =({"owner_name":item_owner}) 
    
    return jsonify({'message':'please enter correct  information'} if item_owner =={} else result)
    cursor.close() 
    conn.close()

########### ITEM PREVIOUS OWNER ###############

@app.route('/api/micro/v1.0.0/owner/previous/item/owner/<string:gtin>')                                                       # url
def previous_item_owner(gtin):
    previous_owner = []
    item_owner = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_item_transactions_trace WHERE product_gtin=%s",gtin)
    item_owner_data = cursor.fetchall()

    for i in item_owner_data:
        if request.args:
            lot_num = request.args.get('lotnumber')
            serial_num = request.args.get('serial_number')
            if gtin == i['product_gtin'] and lot_num == i['batch_no'] and serial_num == i['package_sn'] :

                previous_owner.append({
                'owner_name': i['current_owner_name'], 
                'gtin_number': i['product_gtin'], 'lot_number': i['batch_no'],
                'serial_number': i['package_sn'],
                'gln':i['current_owner_gln']
                 })

    previous_owner = previous_owner[-2:-1]
    result =({"previous_owner_name":previous_owner}) 
    
    return jsonify({'message':'please enter correct information'} if previous_owner == [] else result)
    cursor.close() 
    conn.close()


########### ITEM'S ALL PREVIOUS OWNER ###############

@app.route('/api/micro/v1.0.0/owner/previous/item/owner_list/<string:gtin>')                                                       # url
def item_owner_hisotry(gtin):
    previous_owner = []
    item_owner = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_item_transactions_trace WHERE product_gtin=%s",gtin)
    item_owner_data = cursor.fetchall()

    for i in item_owner_data:
        if request.args:
            lot_num = request.args.get('lotnumber')
            serial_num = request.args.get('serial_number')
            if gtin == i['product_gtin'] and lot_num == i['batch_no'] and serial_num == i['package_sn'] :

                previous_owner.append({
                'owner_name': i['current_owner_name'], 
                'gtin_number': i['product_gtin'], 'lot_number': i['batch_no'],
                'serial_number': i['package_sn'],
                'gln':i['current_owner_gln']
                 })

    # previous_owner = previous_owner[-2:-1]
    result =({"all_previous_owner_name":previous_owner}) 
    
    return jsonify({'message':'please enter correct information'} if previous_owner == [] else result)
    cursor.close() 
    conn.close()


#####################################################
    '''            item   location                '''
#####################################################
#############   CURRENT  ITEM LOCATION ################
@app.route('/api/micro/v1.0.0/owner/current/item/location/<string:gtin>')                                                       # url
def current_item_location(gtin):
    item_loc = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_location_summary WHERE gtin=%s",gtin)
    item_owner_data = cursor.fetchall()

    if request.args:
        lot_num = request.args.get('lotnumber')
        serial_num = request.args.get('serial_number')

    for i in item_owner_data:
        
            if gtin == i['gtin'] and serial_num == i['package_sn'] :
                item_loc['latitude'] = i['current_lat']
                item_loc['longitude'] = i['current_long']
                item_loc['serial_number'] =  i['package_sn']
                item_loc['gtin_number'] = i['gtin']
                item_loc['gln']  =  i['company_gln']
                item_loc['address']  =  i['current_location']

    result =({"item_location":item_loc}) 
    
    return jsonify({'message':'please enter correct information'} if item_loc == {} else result)
    cursor.close() 
    conn.close()

#############   PREVIOUS ITEM LOCATION ################
@app.route('/api/micro/v1.0.0/owner/previous/item/location/<string:gtin>')                                                       # url
def previous_item_location(gtin):
    item_prev_loc = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace WHERE product_gtin=%s",gtin)
    item_owner_data = cursor.fetchall()

    if request.args:
        lot_num = request.args.get('lotnumber')
        serial_num = request.args.get('serial_number')
    
    for i in item_owner_data:
            if gtin == i['product_gtin'] and serial_num == i['package_sn'] :
                item_prev_loc.append({
                    'serial_number' :  i['package_sn'],
                    'gtin_number' : i['product_gtin'],
                    'gln' :  i['current_owner_gln'],
                    'address' :  i['current_owner_address']

                })
    previous_location = item_prev_loc[-2:-1]
    result =({"item_previous_location":previous_location}) 
    
    return jsonify({'message':'please enter correct information'} if item_prev_loc == {} else result)
    cursor.close() 
    conn.close()


#############  ALL PREVIOUS ITEM LOCATION ################
@app.route('/api/micro/v1.0.0/owner/previous/item/location_list/<string:gtin>')                                                       # url
def all_previous_item_location(gtin):
    item_prev_loc = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace WHERE product_gtin=%s",gtin)
    item_owner_data = cursor.fetchall()

    if request.args:
        lot_num = request.args.get('lotnumber')
        serial_num = request.args.get('serial_number')
    
    for i in item_owner_data:
            if gtin == i['product_gtin'] and serial_num == i['package_sn'] :
                item_prev_loc.append({
                    'serial_number' :  i['package_sn'],
                    'gtin_number' : i['product_gtin'],
                    'gln' :  i['current_owner_gln'],
                    'address' :  i['current_owner_address']
                })
    previous_location = item_prev_loc
    result =({"item_previous_location":previous_location}) 
    
    return jsonify({'message':'please enter correct information'} if item_prev_loc == {} else result)
    cursor.close() 
    conn.close()


#####################################################
    '''            item   Status                '''
#####################################################
@app.route('/api/micro/v1.0.0/owner/current/item/status/<string:gtin>')                                                       # url
def item_status(gtin):
    status = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace WHERE product_gtin=%s",gtin)
    item_owner_data = cursor.fetchall()

    if request.args:
        lot_num = request.args.get('lotnumber')
        serial_num = request.args.get('serial_number')

    for i in item_owner_data:
        
            if gtin == i['product_gtin'] and serial_num == i['package_sn'] and lot_num == i['batch_no']:
                status['serial_number'] =  i['package_sn']
                status['gtin_number'] = i['product_gtin']
                status['gln']  =  i['current_owner_gln']
                status['status'] = i['event_type']
                
    result =({"transaction_status":status}) 
    
    return jsonify({'message':'please enter correct information'} if status == {} else result)
    cursor.close() 
    conn.close()






###########################################################################
'''                             PACKAGE MICROSRVICES                   '''
###########################################################################

######################## PACKAGE CATEGORY #############################

@app.route('/api/micro/v1.0.0/packages/category/<string:sscc>')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def sscc_category(sscc):

    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT gtin, product_gtin_id, lot_id, batch_no, sscc_no, package_type  FROM vw_package WHERE sscc_no=%s",sscc)
    package_data = cursor.fetchall()
    package_cat = []
    sscc_info = {}
    for i in package_data:
        if i['sscc_no'] == sscc:
            sscc_info['gtin_number'] = i['gtin']
            sscc_info['gtin_id'] = i['product_gtin_id']
            sscc_info['lot_id'] = i['lot_id']
            sscc_info['lot_number'] = i['batch_no']
            sscc_info['sscc_number'] = i['sscc_no']
            sscc_info['package_category'] = i['package_type']

    result =({'package_category':sscc_info}) 

    return jsonify({'message': 'SSCC number is not available'}if sscc_info == {} else result)
    cursor.close() 
    conn.close()


########################### PACKAGE INFORMATION ##########################

@app.route('/api/micro/v1.0.0/packages/information/<string:sscc>')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def sscc_inofrmation(sscc):

    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_package WHERE sscc_no=%s",sscc)
    package_data = cursor.fetchall()

    result =({'package_information':package_data}) 

    return jsonify({'message': 'SSCC number is not available'}if result == {} else result)
    cursor.close() 
    conn.close()

########################package inner list ##################

@app.route('/api/micro/v1.0.0/packages/innerlist/<string:sscc>')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def package_innerlist(sscc):
    sscc_info= {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_package WHERE sscc_no=%s",sscc)
    package_data = cursor.fetchall()
    for i in package_data:
        sscc_info['sscc_no'] = i['sscc_no']
        sscc_info['id'] = i['id']
        sscc_info['package_inner_list'] = i['inner_serail_list']


    result ={'innerlist_information':sscc_info}
    return jsonify({'message': 'SSCC number is not available'}if sscc_info == {} else result)
    cursor.close() 
    conn.close()

############################ PACKAGE STATUS ##################

@app.route('/api/micro/v1.0.0/packages/status/<string:sscc>')        #/api/micro/v1/product/item-serial-list-count?lotnumber= 12345
def package_status(sscc):
    sscc_info= {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor) 
    cursor.execute("SELECT sscc_no, id, is_active  FROM vw_package WHERE sscc_no=%s",sscc)
    package_data = cursor.fetchall()
    for i in package_data:
        sscc_info['sscc_no'] = i['sscc_no']
        sscc_info['id'] = i['id']
        if i['is_active'] == 1:
            sscc_info['status'] = 'status is active'
        else:
            sscc_info['status'] = 'status is inactive'
        
    result ={'package_status':sscc_info}
    return jsonify({'message': 'SSCC number is not available'}if sscc_info == {} else result)
    cursor.close() 
    conn.close()

#############################################################################
'''                   PACKAGE OWNER AND LOCATION             ''' 
##############################################################################

########### PACKAGE CURRENT OWNER ###############

########### PACKAGE CURRENT OWNER ###############

@app.route('/api/micro/v1.0.1/package/current/owners/<string:sscc>')  # url
def current_package_owner(sscc):
    package_owner = {}
    package = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        "SELECT current_owner_name, product_gtin, batch_no, package_sn, sscc_no FROM vw_item_transactions_trace WHERE sscc_no=%s",
        sscc)
    previous_owner_data = cursor.fetchall()

    for i in previous_owner_data:
        if sscc == i['sscc_no']:
            package_owner['owner_name'] = i['current_owner_name']
            package_owner['sscc'] = i['sscc_no']

    result = ({"owner_name": package_owner})

    return jsonify({'message': 'please enter correct information'} if package == {} else result)
    cursor.close()
    conn.close()


########### ITEM PREVIOUS OWNER ###############

@app.route('/api/micro/v1.0.0/packages/previous/owners/<string:sscc>')                                                       # url
def previous_package_owner(sscc):
    previous_owner = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_item_transactions_trace WHERE sscc_no=%s",sscc)
    item_owner_data = cursor.fetchall()

    for i in item_owner_data:
        if sscc == i['sscc_no'] :

            previous_owner.append({
            'owner_name': i['current_owner_name'], 
            'gtin_number': i['product_gtin'], 'lot_number': i['batch_no'],
            'serial_number': i['package_sn'],
            'gln':i['current_owner_gln'],
            'sscc':i['sscc_no']
                })

    previous_owner = previous_owner[-2:-1]
    result =({"previous_owner_name":previous_owner}) 
    return jsonify({'message':'please enter correct information'} if previous_owner == [] else result)
    cursor.close() 
    conn.close()


# ########### package ALL PREVIOUS OWNER ###############

@app.route('/api/micro/v1.0.0/packages/previous/owners_list/<string:sscc>')                                                       # url
def all_package_owner_hisotry(sscc):
    previous_owner = []
    item_owner = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM vw_item_transactions_trace WHERE sscc_no=%s",sscc)
    item_owner_data = cursor.fetchall()

    for i in item_owner_data:

        if sscc == i['sscc_no']  :

            previous_owner.append({
            'owner_name': i['current_owner_name'], 
            'sscc' : i['sscc_no'] })

    previous_owner = list({v['owner_name']:v for v in previous_owner}.values())
    result =({"all_previous_owner_name":previous_owner}) 
    
    return jsonify({'message':'please enter correct information'} if previous_owner == [] else result)
    cursor.close() 
    conn.close()


#####################################################
    '''            packages   location                '''
#####################################################

#############   CURRENT  PACKAGE LOCATION ################
@app.route('/api/micro/v1.0.0/package/current/location/<string:sscc>')  # url
def package_current_location(sscc):
    package_loc = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_location_summary WHERE sscc_no=%s", sscc)
    package_location_data = cursor.fetchall()

    for i in package_location_data:

        if sscc == i['sscc_no']:
            package_loc['sscc_number'] = i['sscc_no']
            package_loc['gln'] = i['company_gln']
            package_loc['address'] = i['current_location']

    result = ({"package_location": package_loc})

    return jsonify({'message': 'please enter correct information'} if package_loc == {} else result)
    cursor.close()
    conn.close()


#############   PREVIOUS PACKAGE LOCATION ################
@app.route('/api/micro/v1.0.0/packages/previous/location/<string:sscc>')  # url
def packages_previous_location(sscc):
    package_prev_loc = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace WHERE sscc_no=%s", sscc)
    package_prev_location_data = cursor.fetchall()

    for i in package_prev_location_data:
        if sscc == i['sscc_no']:
            package_prev_loc.append({
                'gln': i['current_owner_gln'],
                'address': i['current_owner_address'],
                'sscc': i['sscc_no']
            })
    previous_location = package_prev_loc[-2:-1]
    result = ({"package_previous_location": previous_location})

    return jsonify({'message': 'please enter correct information'} if package_prev_loc == [] else result)
    cursor.close()
    conn.close()


# #############  ALL PREVIOUS PACKAGE LOCATION ################
@app.route('/api/micro/v1.0.0/packages/previous/item/location_list/<string:sscc>')  # url
def all_previous_packages_location(sscc):
    item_prev_loc = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace WHERE sscc_no=%s", sscc)
    item_owner_data = cursor.fetchall()

    for i in item_owner_data:
        if sscc == i['sscc_no']:
            item_prev_loc.append({
                'gln': i['current_owner_gln'],
                'address': i['current_owner_address'],
                'sscc': i['sscc_no']
            })
    previous_location = list({v['gln']: v for v in item_prev_loc}.values())

    result = ({"package_previous_locations": previous_location})

    return jsonify({'message': 'please enter correct information'} if item_prev_loc == [] else result)
    cursor.close()
    conn.close()

    #####################################################
    '''            item   Status                '''
#####################################################
@app.route('/api/micro/v1.0.0/packages/current/transaction_status/<string:sscc>')                                                       # url
def package_transaction_status(sscc):
    status = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace WHERE sscc_no=%s",sscc)
    item_owner_data = cursor.fetchall()

    for i in item_owner_data:
        if sscc == i['sscc_no']:
            status['sscc'] = i['sscc_no']
            status['gln']  =  i['current_owner_gln']
            status['status'] = i['event_type']
                
    result =({"transaction_status":status}) 
    
    return jsonify({'message':'please enter correct information'} if status == {} else result)
    cursor.close() 
    conn.close()

######################################################################


#############   ENTRY POINT PACKAGE LOCATION ################

@app.route('/api/micro/v1.0.0/package/entry/location/<string:sscc>')  # url
def package_entry_location(sscc):
    package_entryPoint_loc = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace WHERE sscc_no=%s", sscc)
    entry_point_location_data = cursor.fetchall()

    for i in entry_point_location_data:

        if sscc == i['sscc_no']:
            package_entryPoint_loc['sscc_number'] = i['sscc_no']
            package_entryPoint_loc['address'] = i['entry_point_owner_location']
            package_entryPoint_loc['owner'] = i['entry_point_owner']

    result = ({"entry_point_package_location": package_entryPoint_loc})

    return jsonify({'message': 'please enter correct information'} if package_entryPoint_loc == {} else result)

    cursor.close()
    conn.close()


#############   EXIT POINT PACKAGE LOCATION ################

@app.route('/api/micro/v1.0.0/package/exit/location/<string:sscc>')  # url
def package_exit_location(sscc):
    package_exitPoint_loc = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace WHERE sscc_no=%s", sscc)
    exit_point_location_data = cursor.fetchall()

    for i in exit_point_location_data:

        if sscc == i['sscc_no']:
            package_exitPoint_loc['sscc_number'] = i['sscc_no']
            package_exitPoint_loc['address'] = i['exit_point_owner_location']
            package_exitPoint_loc['owner'] = i['exit_point_owner']

    result = ({"exit_point_package_location": package_exitPoint_loc})

    return jsonify({'message': 'please enter correct information'} if package_exitPoint_loc == {} else result)

    cursor.close()
    conn.close()


#############   EXIT POINT PACKAGE GEO LOCATION ################

@app.route('/api/micro/v1.0.0/package/exit/geo/location/<string:sscc>')  # url
def package_exit_geo_location(sscc):
    package_exitPoint_geo_loc = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_location_summary WHERE sscc_no=%s", sscc)
    exit_point_geo_location_data = cursor.fetchall()

    for i in exit_point_geo_location_data:

        if sscc == i['sscc_no']:
            package_exitPoint_geo_loc['sscc_number'] = i['sscc_no']
            package_exitPoint_geo_loc['latitude'] = i['exit_latitude']
            package_exitPoint_geo_loc['logitude'] = i['exit_long']
            package_exitPoint_geo_loc['gln'] = i['exit_point_gln']

    result = ({"exit_point_package_geo_location": package_exitPoint_geo_loc})

    return jsonify({'message': 'please enter correct information'} if package_exitPoint_geo_loc == {} else result)

    cursor.close()
    conn.close()


#############   ENTRY POINT PACKAGE GEO LOCATION ################

@app.route('/api/micro/v1.0.0/package/entry/geo/location/<string:sscc>')  # url
def package_entry_geo_location(sscc):
    package_entryPoint_geo_loc = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_location_summary WHERE sscc_no=%s", sscc)
    entry_point_geo_location_data = cursor.fetchall()

    for i in entry_point_geo_location_data:

        if sscc == i['sscc_no']:
            package_entryPoint_geo_loc['sscc_number'] = i['sscc_no']
            package_entryPoint_geo_loc['latitude'] = i['entry_lat']
            package_entryPoint_geo_loc['logitude'] = i['entry_long']
            package_entryPoint_geo_loc['gln'] = i['entry_point_gln']

    result = ({"entry_point_package_geo_location": package_entryPoint_geo_loc})

    return jsonify({'message': 'please enter correct information'} if package_entryPoint_geo_loc == {} else result)

    cursor.close()
    conn.close()


################################ current geo location ##########################


@app.route('/api/micro/v1.0.0/package/current/geo/location/<string:sscc>')  # url
def package_current_geo_location(sscc):
    package_currentPoint_geo_loc = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_location_summary WHERE sscc_no=%s", sscc)
    current_point_geo_location_data = cursor.fetchall()

    for i in current_point_geo_location_data:

        if sscc == i['sscc_no']:
            package_currentPoint_geo_loc['sscc_number'] = i['sscc_no']
            package_currentPoint_geo_loc['latitude'] = i['current_lat']
            package_currentPoint_geo_loc['logitude'] = i['current_long']

    result = ({"current_point_package_geo_location": package_currentPoint_geo_loc})

    return jsonify({'message': 'please enter correct information'} if package_currentPoint_geo_loc == {} else result)

    cursor.close()
    conn.close()


##################### PACKAGE ENTRY POINT OWNER #######################

@app.route('/api/micro/v1.0.1/package/entry/owners/<string:sscc>')  # url
def entryPoint_package_owner(sscc):
    entry_package_owner = {}
    package = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        "SELECT entry_point_owner, product_gtin, batch_no, package_sn, sscc_no FROM vw_item_transactions_trace WHERE sscc_no=%s",
        sscc)
    entry_owner_data = cursor.fetchall()

    for i in entry_owner_data:
        if sscc == i['sscc_no']:
            entry_package_owner['entry_point'] = i['entry_point_owner']
            entry_package_owner['sscc'] = i['sscc_no']
            entry_package_owner['gtin'] = i['product_gtin']
            entry_package_owner['serial_number'] = i['package_sn']
            entry_package_owner['lot_number'] = i['batch_no']

    result = ({"entry_point_owner": entry_package_owner})

    return jsonify({'message': 'please enter correct information'} if entry_package_owner == {} else result)
    cursor.close()
    conn.close()
########################## EXIT POINT OWNER ##################################

@app.route('/api/micro/v1.0.1/package/exit/owners/<string:sscc>')  # url
def exitPoint_package_owner(sscc):
    exit_package_owner = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        "SELECT exit_point_owner, product_gtin, batch_no, package_sn, sscc_no FROM vw_item_transactions_trace WHERE sscc_no=%s",
        sscc)
    exit_owner_data = cursor.fetchall()

    for i in exit_owner_data:
        if sscc == i['sscc_no']:
            exit_package_owner['exit_point'] = i['exit_point_owner']
            exit_package_owner['sscc'] = i['sscc_no']
            exit_package_owner['gtin'] = i['product_gtin']
            exit_package_owner['serial_number'] = i['package_sn']
            exit_package_owner['lot_number'] = i['batch_no']

    result = ({"exit_point_owner": exit_package_owner})

    return jsonify({'message': 'please enter correct information'} if exit_package_owner == {} else result)
    cursor.close()
    conn.close()


######################################################################################
'''                         PACKAGE HANDOFF TIMESTAMP'''
######################################################################################

@app.route('/api/micro/v1.0.0/packages/handofftime/<string:sscc>')  # url
def package_handoff_timestamp(sscc):
    timestamp = {}
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace WHERE sscc_no=%s", sscc)
    item_owner_data = cursor.fetchall()

    for i in item_owner_data:
        if sscc == i['sscc_no']:
            timestamp['sscc'] = i['sscc_no']
            timestamp['gln'] = i['current_owner_gln']
            timestamp['handoff_timestamp'] = i['transaction_timestamp']
            timestamp['owner_name'] = i['current_owner_name']
            timestamp['from_owner'] = i['name_sender']
            timestamp['to_owner'] = i['name_reciver']

    result = ({"handoff_time": timestamp})

    return jsonify({'message': 'please enter correct information'} if timestamp == {} else result)
    cursor.close()
    conn.close()


######################################################################################
'''                         ITEM HANDOFF TIMESTAMP                      '''


######################################################################################

@app.route('/api/micro/v1.0.0/items/handofftime/<string:gtin>')  # url
def item_handoff_timestamp(gtin):
    timestamp = {}
    item_prev_timestamp = []

    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  vw_item_transactions_trace WHERE product_gtin = %s ", gtin)
    item_owner_data = cursor.fetchall()

    if request.args:
        lot_num = request.args.get('lotNumber')
        serial_num = request.args.get('serialNumber')

    for i in item_owner_data:
        if gtin == i['product_gtin'] and serial_num == i['package_sn']:
            item_prev_timestamp.append({
                'serial_number': i['package_sn'],
                'gtin_number': i['product_gtin'],
                'from_owner': i['name_sender'],
                'to_owner': i['name_reciver'],
                'current_owner': i['current_owner_name'],
                'handoff_timestamp': i['transaction_timestamp']
            })

    result = ({"item_previous_timestamp": item_prev_timestamp[1:]})

    return jsonify({'message': 'please enter correct information'} if item_prev_timestamp == [] else result)
    cursor.close()
    conn.close()
###############
######################################################################################
'''                         USER LIST'''
######################################################################################

@app.route('/api/micro/v1.0.0.1/user/list/<string:organization_id>')  # url
def package_handoff_timestamps(organization_id):
    data = {}
    timestamp = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  api_user WHERE organization_id = %s ", organization_id)
    user_list = cursor.fetchall()
    if request.args:
        organization_id = request.args.get('organization_id')
    for i in user_list:
        #if organization_id == i['organization_id'] :
            timestamp.append({
                #'organization_id': i['organization_id'],
                #'first_name': i['first_name']

            })


    result = ({"user_list": user_list})

    return jsonify({'data': 'please enter correct information'} if timestamp == [] else result)
    cursor.close()
    conn.close()

######################################################
@app.route('/api/micro/v1.0.0/user/list/<string:id>')  # url
def admin_user_list(id):
    data = {}
    timestamp = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  api_user WHERE organization_id = %s ",id)
    user_list = cursor.fetchall()


    result = ({"user_list": user_list})

    return jsonify(result)
    cursor.close()
    conn.close()

######################################################

@app.route('/api/micro/v1.0.0/admin/user/list/<string:id>')  # url
def adminUserList(id):
    data = {}
    timestamp = []
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  api_user WHERE add_user_id = %s ",id)
    user_list = cursor.fetchall()


    result = ({"user_list": user_list})

    return jsonify(result)
    cursor.close()
    conn.close()

###########################
@app.route('/api/micro/v1.0.0/user/lists')
def api_list():
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM  api_user")
    api_user = cursor.fetchall()
    result = {'user_list': api_user}
    return jsonify(result)
    cursor.close()
    conn.close()

#############

@app.route('/update/<string:id>', methods=['PUT'])
def update_student(id):
    try:
        _json = request.json
        _id = _json['id']
        _first_name = _json['first_name']
        _last_name = _json['last_name']
        #_class = _json['class']
        #_age = _json['age']
        #_address = _json['address']

        # update record in database
        sql = ("UPDATE api_user SET first_name=%s, last_name=%s WHERE id=%s",id)
        data = (_first_name, _last_name, _id,)
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(sql, data)
        conn.commit()
        res = jsonify('Student updated successfully.')
        return jsonify(res)
    finally:
        cursor.close()
        conn.close()

#########
@app.route('/emp/<int:id>/')
def emp(id):
    try:
        conn = mysql.connect()
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute("SELECT id, first_name, email, last_name FROM api_user WHERE id =%s", id)
        empRow = cursor.fetchone()
        respone = jsonify(empRow)
        respone.status_code = 200
        return respone
    except Exception as e:
        print(e)
    finally:
        cursor.close()
        conn.close()
##################

#########
@app.route('/update', methods=['PUT'])
def update_emp():
    try:
        _json = request.json
        _id = _json['id']
        _first_name = _json['first_name']
        _email = _json['email']
        _last_name = _json['last_name']
        #_address = _json['address']
        if _first_name and _email and _last_name and  _id and request.method == 'PUT':
            sqlQuery = "UPDATE api_user SET full_name=%s, email=%s, last_name=%s WHERE id=%s"
            bindData = (_first_name, _email, _last_name, _id,)
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute(sqlQuery, bindData)
            conn.commit()
            respone = jsonify('Employee updated successfully!')
            respone.status_code = 200
            return respone
        else:
            return "error"
    except Exception as e:
        print(e)
    finally:
        cursor.close()
        conn.close()

###########

if __name__ == "__main__":
    app.run(host='0.0.0.0',port=8003,debug=True)
