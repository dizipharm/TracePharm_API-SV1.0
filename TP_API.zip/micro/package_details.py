from datetime import time

import pymysql
from django.contrib.sites import requests
from flask import request, jsonify  # joson format
from flaskext.mysql import MySQL
from flask import Flask
from flask_cors import CORS, cross_origin
##################################
from pandas.tests.scalar import timestamp

app = Flask(__name__)
CORS(app)
###################################

''' Database Connection '''

mysql = MySQL()
app.config['MYSQL_DATABASE_HOST'] = '54.236.245.46'
app.config['MYSQL_DATABASE_USER'] = 'phpmyadmin'
app.config['MYSQL_DATABASE_PASSWORD'] = 'Admin@123'
app.config['MYSQL_DATABASE_DB'] = 'TracePharmVersion1'
mysql.init_app(app)

###########################################################################################
@app.route('/api/v1.0.0/exp/package_details/<string:sscc>')
def track_pack(sscc):
    t1 = time.time()
    track_info = requests.get('http://3.86.246.56:5000/api/v2/product/track').json()
    f_locations = []
    f_controll_conditions = []
    f_owners = []
    f_transaction_event = []
    f_transaction_status = []
    f_package = []
    f_gtin_info = []

    package_info = {}
    package = {}
    gtin_info = {}
    owner_data = {}
    entry_point = {}
    exit_point = {}
    controll_condition = {}
    owner_data_location = {}
    location = {}
    entry_point_location = {}
    exit_point_location = {}
    transaction_event = {}
    transaction_status = {}

    for i in track_info['track_info']:
        if i['package_info']['sscc_no'] == sscc:

            gtin_info['gtin'] = i['package_info']['gtin']
            gtin_info['product_name'] = i['package_info']['product_name']
            gtin_info['brand_name'] = i['package_info']['brand_name']
            gtin_info['dosage_form'] = i['package_info']['dosage_form']
            gtin_info['mfg_name'] = i['package_info']['mfg_name']
            gtin_info['mfg_gln'] = i['package_info']['mfg_gln']
            gtin_info['NDC'] = i['package_info']['NDC']
            gtin_info['mfg_address'] = i['package_info']['mfg_address']
            package['colour'] = i['package_info']['colour']
            package['depth'] = i['package_info']['depth']
            package['height'] = i['package_info']['height']
            #package['inner_serail_list'] = i['package_info']['inner_serail_list']
            package['inner_serail_count'] = i['package_info']['package_inside_units']
            package['package_gross_weight'] = i['package_info']['package_gross_weight']
            package['package_pallet_sn'] = i['package_info']['package_pallet_sn']
            package['package_type'] = i['package_info']['package_type']
            package['lot_number'] = i['package_info']['batch_no']
            gtin_info['lot_number'] = i['package_info']['batch_no']
            gtin_info['mfg_date'] = i['package_info']['mfg_date']
            gtin_info['exp_date'] = i['package_info']['expiry_date']
            package['shape'] = i['package_info']['shape']
            package['sscc_no'] = i['package_info']['sscc_no']
            package['total_dimensions'] = i['package_info']['total_dimensions']
            package['width'] = i['package_info']['width']
            if i['package_info']['is_active'] == 1:
                package['status'] = 'status is active'
            else:
                package['status'] = 'status is in-active'

        current_owner = requests.get(i['current_owner']).json()
        owner = current_owner['package_transaction']

        for j in owner:
            if sscc == j['sscc_no']:
                owner_data['current_owner'] = j['current_owner']
                owner_data['current_owner_address'] = j['consigner_address']
                entry_point['owner'] = j['consigner']
                entry_point['address'] = j['consigner_address']

                exit_point['comapny_name'] = j['consignee']
                exit_point['company_address'] = j['consignee_address']

                transaction_event['handoff_event'] = j['tranc_date_time']
                transaction_status['transaction_status'] = j['event_type']

        current_location = requests.get(i['current_location']).json()
        location_curr = current_location['transaction']
        for k in location_curr:
            if sscc == k['sscc_no']:
                owner_data['gln'] = k['company_gln']
                location['current_lat'] = k['current_lat']
                location['current_long'] = k['current_long']
                location['current_address'] = k['current_location']

                entry_point_location['latitude'] = k['entry_lat']
                entry_point_location['longitude'] = k['entry_long']
                entry_point['gln'] = k['entry_point_gln']

                exit_point_location['latitude'] = k['exit_latitude']
                exit_point_location['longitude'] = k['exit_long']
                exit_point['gln'] = k['exit_point_gln']

                controll_condition['temperature'] = k['temperature']
                controll_condition['humidity'] = k['humidity']

    f_locations.append({'current_location': location})
    f_locations.append({'entry_point_location': entry_point_location})
    f_locations.append({'exit_point_location': exit_point_location})

    f_controll_conditions.append({'controll_condition': controll_condition})

    f_owners.append({'entry_point_owner': entry_point})
    f_owners.append({'current_owner': owner_data})
    f_owners.append({'exit_point_ower': exit_point})

    f_transaction_event.append({'transaction_event': transaction_event})
    f_transaction_status.append({'transaction_status': transaction_status})

    f_package.append({'package_information': package})
    f_gtin_info.append({'gtin_information': gtin_info})

    t2 = time.time()
    time_1 = ("Elasped Time(Sec): ", round(t2 - t1, 5), "sec")

    package_info['locations'] = f_locations,
    package_info['controll_conditions'] = f_controll_conditions,
    package_info['owner'] = f_owners
    package_info['transaction_event'] = f_transaction_event
    package_info['status'] = f_transaction_status
    # package_info['lot_information'] = f_lot
    package_info['gtin_information'] = f_gtin_info
    package_info['package_information'] = f_package

    result = {'track': package_info, 'response_time': time_1}
    return jsonify({'message': 'no records found'} if package_info == {} else result)



###########

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8003, debug=True)