# from flask import Flask,render_template, request, Response, jsonify
# from flask_mysqldb import MySQL
# import pymysql
# import pandas as pd


# app = Flask(__name__)

# # MySql = MySQL()
# # app.config['MYSQL_HOST'] = ' http://54.236.245.46'
# # app.config['MYSQL_USER'] = 'phpmyadmin'
# # app.config['MYSQL_PASSWORD'] = 'Admin@123'
# # app.config['MYSQL_DB'] = 'TracePharmVersion1'
# # mysql = MySql.init_app(app)

# @app.route("/api/v1/test", methods=['GET', 'POST'])
# def database():
#     db = pymysql.connect(host='54.236.245.46',  # your host name is often 'localhost'
#                         user='phpmyadmin',            
#                         passwd='Admin@123',  
#                         db='TracePharmVersion1')  

    
#     data = pd.read_sql("select * from mt_product_gtin", db)
#     data = data.to_json()
#     db.close()
#     return jsonify({'data': data})

# if __name__ == "__main__":
#     app.run(host=app.config['SERVER_NAME'],port=8000,debug=True) 


# # @app.route('/product')

# # def product():
# #     try:
# #         connection = mysql.connect()
# #         pointer = connection.cursor(pymysql.cursors.DictCursor)
# #         pointer.execute('select * from tp_package_primary ')
# #         record = pointer.fetchone()
# #         response = jsonify(record)
# #         response.status_code = 200
# #         return response
# #     except Exception as e:
# #         return error
# #     finally:
# #         pointer.close()


# # app.execute()
# # pointer.colse()
 






## database connection 


from app import app
from flaskext.mysql import MySQL
from datetime import datetime


mysql = MySQL()
app.config['MYSQL_DATABASE_HOST'] = '54.236.245.46'
app.config['MYSQL_DATABASE_USER'] = 'phpmyadmin'
app.config['MYSQL_DATABASE_PASSWORD'] = 'Admin@123'
app.config['MYSQL_DATABASE_DB'] = 't&p_version1'
mysql.init_app(app)

















